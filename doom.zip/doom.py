"""
doom.py — ASCII raycaster FPS for Flux OS
fpt install doom
"""

MANIFEST = {
    "name":        "doom",
    "version":     "1.0.0",
    "description": "ASCII raycaster FPS — Doom-inspired terminal shooter",
    "commands":    ["doom"],
    "author":      "FluxTeam",
}

import os, sys, math, time, random, threading

try:
    import curses
except ImportError:
    def run(kernel):
        print("doom: curses not available on this platform.")
    _has_curses = False
else:
    _has_curses = True


# ── Map (# = wall, . = floor, E = enemy spawn, K = key, X = exit) ────────────
MAP = [
    "####################",
    "#.....#............#",
    "#.###.#.##########.#",
    "#.#E#.#.#........#.#",
    "#.###...#.######.#.#",
    "#.......#.#....#.#.#",
    "#.#######.#.##.#.#.#",
    "#.#.......#.##.#.#.#",
    "#.#.#######....#.#.#",
    "#.#.#..E.......#.#.#",
    "#.#.###########.##.#",
    "#.#...........K....#",
    "#.#################X",  # X = exit door
    "#..................#",
    "#..E...............#",
    "###################",
]
MAP_W = len(MAP[0])
MAP_H = len(MAP)

FOV        = math.pi / 3      # 60 degrees
MAX_DEPTH  = 20
NUM_RAYS   = 60               # columns to cast
MOVE_SPEED = 0.08
ROT_SPEED  = 0.06
ENEMY_SPEED = 0.015

WALL_CHARS  = ["█", "▓", "▒", "░", "·"]
FLOOR_CHARS = ["·", " "]
SKY_CHAR    = " "

KEYS = {
    "w": "forward", "s": "back",
    "a": "left",    "d": "right",
    "q": "exit",
}

# ─────────────────────────────────────────────────────────────────────────────

def _tile(x, y):
    xi, yi = int(x), int(y)
    if 0 <= yi < MAP_H and 0 <= xi < MAP_W:
        return MAP[yi][xi]
    return "#"

def _is_wall(x, y):
    t = _tile(x, y)
    return t == "#"

def _cast_ray(px, py, angle):
    sin_a = math.sin(angle)
    cos_a = math.cos(angle)
    for depth in range(1, MAX_DEPTH * 10):
        d = depth * 0.05
        tx = px + cos_a * d
        ty = py + sin_a * d
        if _is_wall(tx, ty):
            return d, _tile(tx, ty)
    return float(MAX_DEPTH), "."


class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.hp = 3
        self.alive = True
        self._timer = 0

    def update(self, px, py):
        if not self.alive:
            return
        self._timer += 1
        if self._timer % 8 != 0:
            return
        dx = px - self.x
        dy = py - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.5:
            return
        nx = self.x + (dx / dist) * ENEMY_SPEED * 8
        ny = self.y + (dy / dist) * ENEMY_SPEED * 8
        if not _is_wall(nx, ny):
            self.x, self.y = nx, ny

    def angle_from(self, px, py):
        return math.atan2(self.y - py, self.x - px)

    def dist_from(self, px, py):
        return math.hypot(self.x - px, self.y - py)


class DoomGame:
    def __init__(self, scr):
        self.scr   = scr
        self.px    = 1.5
        self.py    = 1.5
        self.angle = 0.0
        self.hp    = 100
        self.ammo  = 30
        self.score = 0
        self.has_key = False
        self.won   = False
        self.flash_msg  = ""
        self.flash_timer = 0
        self.shot_flash  = 0
        self.hurt_flash  = 0
        self.enemies = []
        self._spawn_enemies()
        self.running = True

    def _spawn_enemies(self):
        for y, row in enumerate(MAP):
            for x, ch in enumerate(row):
                if ch == "E":
                    self.enemies.append(Enemy(x + 0.5, y + 0.5))

    def flash(self, msg, t=30):
        self.flash_msg   = msg
        self.flash_timer = t

    def shoot(self):
        if self.ammo <= 0:
            self.flash("*CLICK* — OUT OF AMMO!", 25)
            return
        self.ammo -= 1
        self.shot_flash = 6
        # Check hit — enemy within ~15° of centre and < 8 units away
        for e in self.enemies:
            if not e.alive:
                continue
            ea = e.angle_from(self.px, self.py)
            da = (ea - self.angle + math.pi) % (2 * math.pi) - math.pi
            if abs(da) < 0.15 and e.dist_from(self.px, self.py) < 8:
                e.hp -= 1
                if e.hp <= 0:
                    e.alive = False
                    self.score += 100
                    self.flash("ENEMY DOWN! +100", 20)
                else:
                    self.flash(f"HIT! ({e.hp} HP left)", 15)
                return
        self.flash("missed.", 10)

    def move(self, key):
        nx, ny = self.px, self.py
        if key == ord("w"):
            nx += math.cos(self.angle) * MOVE_SPEED
            ny += math.sin(self.angle) * MOVE_SPEED
        elif key == ord("s"):
            nx -= math.cos(self.angle) * MOVE_SPEED
            ny -= math.sin(self.angle) * MOVE_SPEED
        elif key == ord("a"):
            self.angle -= ROT_SPEED; return
        elif key == ord("d"):
            self.angle += ROT_SPEED; return
        elif key == ord(" ") or key == ord("f"):
            self.shoot(); return

        # collision
        if not _is_wall(nx, self.py): self.px = nx
        if not _is_wall(self.px, ny): self.py = ny

        # tile interactions
        t = _tile(self.px, self.py)
        if t == "K" and not self.has_key:
            self.has_key = True
            self.score += 200
            self.flash("KEY PICKED UP! Find the exit!", 40)
        if t == "X":
            if self.has_key:
                self.won = True
                self.running = False
            else:
                self.flash("DOOR LOCKED — find the key first!", 30)

        # enemy touch damage
        for e in self.enemies:
            if e.alive and e.dist_from(self.px, self.py) < 0.5:
                self.hp -= 1
                self.hurt_flash = 4
                if self.hp <= 0:
                    self.running = False

    def render(self):
        scr = self.scr
        h, w = scr.getmaxyx()
        if h < 10 or w < 20:
            scr.addstr(0, 0, "Terminal too small!")
            scr.refresh()
            return

        half_h = h // 2
        col_w  = max(1, w // NUM_RAYS)
        num_cols = w // col_w

        # ── Raycasting ────────────────────────────────────────────────────────
        for col in range(num_cols):
            ray_angle = self.angle - FOV / 2 + FOV * col / num_cols
            dist, _ = _cast_ray(self.px, self.py, ray_angle)
            # fish-eye correction
            dist = dist * math.cos(ray_angle - self.angle)
            dist = max(0.1, dist)

            wall_h = min(int(half_h * 2 / dist), h - 1)
            top    = max(0, half_h - wall_h // 2)
            bot    = min(h - 1, half_h + wall_h // 2)

            # wall shade by distance
            shade_idx = min(int(dist / MAX_DEPTH * len(WALL_CHARS)), len(WALL_CHARS)-1)
            wch = WALL_CHARS[shade_idx]

            x_pos = col * col_w
            if x_pos >= w - 1:
                break

            # sky
            for row in range(0, top):
                if row < h - 1:
                    try: scr.addstr(row, x_pos, SKY_CHAR * col_w,
                                    curses.color_pair(4))
                    except: pass
            # wall
            for row in range(top, bot + 1):
                if row < h - 1:
                    attr = curses.color_pair(1)
                    if shade_idx == 0: attr |= curses.A_BOLD
                    try: scr.addstr(row, x_pos, wch * col_w, attr)
                    except: pass
            # floor
            for row in range(bot + 1, h - 1):
                fch = FLOOR_CHARS[0] if row > half_h + half_h // 3 else FLOOR_CHARS[1]
                try: scr.addstr(row, x_pos, fch * col_w,
                                curses.color_pair(3))
                except: pass

        # ── Enemies (sprite projection) ───────────────────────────────────────
        for e in sorted(self.enemies, key=lambda e: -e.dist_from(self.px, self.py)):
            if not e.alive:
                continue
            ed = e.dist_from(self.px, self.py)
            if ed < 0.3 or ed > MAX_DEPTH:
                continue
            ea = e.angle_from(self.px, self.py)
            da = (ea - self.angle + math.pi) % (2 * math.pi) - math.pi
            if abs(da) > FOV / 2 + 0.1:
                continue
            sx = int((da / FOV + 0.5) * w)
            sh = min(int(h / ed), h - 2)
            sy = half_h - sh // 2
            sprite = ["@", "M", "W"][min(e.hp - 1, 2)]
            for row in range(max(0, sy), min(h - 2, sy + sh)):
                if 0 <= sx < w - 1:
                    try: scr.addstr(row, sx, sprite, curses.color_pair(2) | curses.A_BOLD)
                    except: pass

        # ── HUD ───────────────────────────────────────────────────────────────
        if self.hurt_flash > 0:
            self.hurt_flash -= 1
            try: scr.addstr(0, 0, "!" * min(w-1, 10), curses.color_pair(2) | curses.A_BOLD)
            except: pass

        hud_left = f" HP:{self.hp:3d}  AMMO:{self.ammo:2d}  SCORE:{self.score}"
        key_str  = " [KEY]" if self.has_key else ""
        hud = hud_left + key_str
        try: scr.addstr(h - 1, 0, hud[:w-1], curses.color_pair(5) | curses.A_BOLD)
        except: pass

        ctrl = " W/S=move  A/D=turn  SPACE=shoot  Q=quit"
        try: scr.addstr(h - 1, max(0, w - len(ctrl) - 1), ctrl[:w-1], curses.color_pair(3))
        except: pass

        # crosshair
        cx = w // 2
        cy = h // 2
        if self.shot_flash > 0:
            self.shot_flash -= 1
            try: scr.addstr(cy, cx, "X", curses.color_pair(2) | curses.A_BOLD)
            except: pass
        else:
            try: scr.addstr(cy, cx, "+", curses.color_pair(5) | curses.A_BOLD)
            except: pass

        # flash message
        if self.flash_timer > 0:
            self.flash_timer -= 1
            fx = max(0, w // 2 - len(self.flash_msg) // 2)
            try: scr.addstr(2, fx, self.flash_msg[:w-1],
                            curses.color_pair(2) | curses.A_BOLD)
            except: pass

        scr.refresh()

    def loop(self):
        scr = self.scr
        scr.nodelay(True)
        scr.keypad(True)
        curses.curs_set(0)

        # colours
        curses.start_color()
        curses.init_pair(1, curses.COLOR_WHITE,   curses.COLOR_BLACK)  # wall
        curses.init_pair(2, curses.COLOR_RED,     curses.COLOR_BLACK)  # enemy/danger
        curses.init_pair(3, curses.COLOR_GREEN,   curses.COLOR_BLACK)  # floor/info
        curses.init_pair(4, curses.COLOR_BLUE,    curses.COLOR_BLACK)  # sky
        curses.init_pair(5, curses.COLOR_YELLOW,  curses.COLOR_BLACK)  # hud

        while self.running:
            scr.clear()
            self.render()

            key = scr.getch()
            if key == ord("q") or key == ord("Q"):
                self.running = False
            elif key != -1:
                self.move(key)

            for e in self.enemies:
                e.update(self.px, self.py)

            time.sleep(0.033)  # ~30 fps

        # End screen
        scr.clear()
        h, w = scr.getmaxyx()
        if self.won:
            lines = ["", "  ██████╗  ██████╗  ██████╗ ███╗   ███╗",
                         "  ██╔══██╗██╔═══██╗██╔═══██╗████╗ ████║",
                         "  ██║  ██║██║   ██║██║   ██║██╔████╔██║",
                         "  ██║  ██║██║   ██║██║   ██║██║╚██╔╝██║",
                         "  ██████╔╝╚██████╔╝╚██████╔╝██║ ╚═╝ ██║",
                         "  ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝     ╚═╝",
                         "", f"  Score: {self.score}   Press any key..."]
            attr = curses.color_pair(3) | curses.A_BOLD
        elif self.hp <= 0:
            lines = ["", "  ██╗   ██╗ ██████╗ ██╗   ██╗    ██████╗ ██╗███████╗██████╗ ",
                         "  ╚██╗ ██╔╝██╔═══██╗██║   ██║    ██╔══██╗██║██╔════╝██╔══██╗",
                         "   ╚████╔╝ ██║   ██║██║   ██║    ██║  ██║██║█████╗  ██║  ██║",
                         "    ╚██╔╝  ██║   ██║██║   ██║    ██║  ██║██║██╔══╝  ██║  ██║",
                         "     ██║   ╚██████╔╝╚██████╔╝    ██████╔╝██║███████╗██████╔╝",
                         "     ╚═╝    ╚═════╝  ╚═════╝     ╚═════╝ ╚═╝╚══════╝╚═════╝ ",
                         "", f"  Score: {self.score}   Press any key..."]
            attr = curses.color_pair(2) | curses.A_BOLD
        else:
            lines = ["", "  Quit.  Score: " + str(self.score), "", "  Press any key..."]
            attr = curses.color_pair(5)

        for i, line in enumerate(lines):
            row = h // 2 - len(lines) // 2 + i
            if 0 <= row < h - 1:
                try: scr.addstr(row, 0, line[:w-1], attr)
                except: pass
        scr.nodelay(False)
        scr.getch()


def run(kernel):
    if not _has_curses:
        print("doom: curses not available.")
        return
    curses.wrapper(_run_curses)


def _run_curses(scr):
    game = DoomGame(scr)
    game.loop()
