"""
doom.py — ASCII raycaster FPS for Flux OS (pure terminal, Windows-compatible)
fpt install doom
"""

MANIFEST = {
    "name":        "doom",
    "version":     "2.0.0",
    "description": "ASCII raycaster FPS — Doom-inspired terminal shooter (no curses)",
    "commands":    ["doom"],
    "author":      "FluxTeam",
}

import os, sys, math, random, time

# ── ANSI helpers ──────────────────────────────────────────────────────────────
R   = "\033[0m"
G   = "\033[92m";  C  = "\033[96m";  Y  = "\033[93m"
RE  = "\033[91m";  D  = "\033[2m";   W  = "\033[97m";  B = "\033[1m"
BGK = "\033[40m";  BGR = "\033[41m"; BGG = "\033[42m"  # bg colours

def g(t):  return f"{G}{t}{R}"
def c(t):  return f"{C}{t}{R}"
def y(t):  return f"{Y}{t}{R}"
def r(t):  return f"{RE}{t}{R}"
def d(t):  return f"{D}{t}{R}"
def w(t):  return f"{W}{B}{t}{R}"
def red(t):return f"{RE}{B}{t}{R}"

def clrscr():
    os.system("cls" if os.name == "nt" else "clear")

# ── Map ───────────────────────────────────────────────────────────────────────
# # = wall  . = floor  E = enemy  K = key  X = exit door
MAP = [
    "####################",
    "#.....#....E.......#",
    "#.###.#.##########.#",
    "#.#E#...#........#.#",
    "#.###...#.######.#.#",
    "#.......#.#....#.#.#",
    "#.#######.#.##.#.#.#",
    "#.#.......#.##.#.#.#",
    "#.#.#######....#.#.#",
    "#.#.#..E.......#.#.#",
    "#.#.###########.##.#",
    "#.#...........K....#",
    "#.#################X",
    "#..................#",
    "#..E...............#",
    "####################",
]
MAP_W = len(MAP[0])
MAP_H = len(MAP)

# ── Raycaster config ──────────────────────────────────────────────────────────
FOV       = math.pi / 3       # 60°
MAX_DEPTH = 16
# We render into a grid of COLS × ROWS characters
COLS = 60
ROWS = 20

# Wall shade chars by distance (near → far)
WALL_SHADES = ["█", "▓", "▒", "░", "·", " "]
FLOOR_CHAR  = "·"
SKY_CHAR    = " "

# ── Tile helpers ──────────────────────────────────────────────────────────────
def tile(x, y):
    xi, yi = int(x), int(y)
    if 0 <= yi < MAP_H and 0 <= xi < MAP_W:
        return MAP[yi][xi]
    return "#"

def is_wall(x, y):
    return tile(x, y) == "#"

# ── Ray cast — returns (distance, tile_char) ──────────────────────────────────
def cast_ray(px, py, angle):
    sa, ca = math.sin(angle), math.cos(angle)
    for step in range(1, MAX_DEPTH * 20):
        d = step * 0.05
        tx, ty = px + ca * d, py + sa * d
        t = tile(tx, ty)
        if t == "#":
            return d, t
    return float(MAX_DEPTH), "."

# ── Enemy ─────────────────────────────────────────────────────────────────────
class Enemy:
    def __init__(self, x, y, idx):
        self.x    = x + 0.5
        self.y    = y + 0.5
        self.hp   = 3
        self.alive = True
        self.idx  = idx          # unique id for display

    def dist(self, px, py):
        return math.hypot(self.x - px, self.y - py)

    def angle_from(self, px, py):
        return math.atan2(self.y - py, self.x - px)

    def step_toward(self, px, py):
        """Move one step closer to the player (called each turn)."""
        if not self.alive: return
        dx, dy = px - self.x, py - self.y
        dist   = math.hypot(dx, dy)
        if dist < 0.6: return
        speed  = 0.25
        nx = self.x + (dx / dist) * speed
        ny = self.y + (dy / dist) * speed
        if not is_wall(nx, self.y): self.x = nx
        if not is_wall(self.x, ny): self.y = ny

# ── Game state ────────────────────────────────────────────────────────────────
class Game:
    def __init__(self):
        self.px      = 1.5
        self.py      = 1.5
        self.angle   = 0.0
        self.hp      = 100
        self.ammo    = 30
        self.score   = 0
        self.has_key = False
        self.msgs    = []        # message log (last N lines shown)
        self.turn    = 0
        self.won     = False
        self.dead    = False
        self.enemies = []
        self._spawn_enemies()

    def _spawn_enemies(self):
        idx = 1
        for y, row in enumerate(MAP):
            for x, ch in enumerate(row):
                if ch == "E":
                    self.enemies.append(Enemy(x, y, idx))
                    idx += 1

    def msg(self, text):
        self.msgs.append(text)
        if len(self.msgs) > 6:
            self.msgs.pop(0)

    def alive_enemies(self):
        return [e for e in self.enemies if e.alive]

    # ── Render ────────────────────────────────────────────────────────────────
    def render(self):
        half = ROWS // 2

        # Build a 2D char+colour grid
        # Each cell: (char, colour_code)
        grid = [[(SKY_CHAR, D)] * COLS for _ in range(ROWS)]

        # ── Raycasting ────────────────────────────────────────────────────────
        depth_buf = []
        for col in range(COLS):
            ray_angle = self.angle - FOV / 2 + FOV * col / COLS
            dist, _   = cast_ray(self.px, self.py, ray_angle)
            # fish-eye correction
            dist = max(0.1, dist * math.cos(ray_angle - self.angle))
            depth_buf.append(dist)

            wall_h = min(int(ROWS / dist), ROWS)
            top    = max(0, half - wall_h // 2)
            bot    = min(ROWS - 1, half + wall_h // 2)

            shade_idx = min(int(dist / MAX_DEPTH * len(WALL_SHADES)),
                            len(WALL_SHADES) - 1)
            wch = WALL_SHADES[shade_idx]

            # sky rows
            for row in range(0, top):
                grid[row][col] = (SKY_CHAR, D)
            # wall rows
            for row in range(top, bot + 1):
                colour = G if shade_idx <= 1 else (Y if shade_idx <= 3 else D)
                grid[row][col] = (wch, colour)
            # floor rows
            for row in range(bot + 1, ROWS):
                grid[row][col] = (FLOOR_CHAR, D)

        # ── Sprite projection (enemies) ───────────────────────────────────────
        for e in sorted(self.alive_enemies(),
                         key=lambda e: -e.dist(self.px, self.py)):
            ed = e.dist(self.px, self.py)
            if ed < 0.3 or ed > MAX_DEPTH: continue
            ea = e.angle_from(self.px, self.py)
            da = (ea - self.angle + math.pi) % (2 * math.pi) - math.pi
            if abs(da) > FOV / 2 + 0.05: continue

            sx = int((da / FOV + 0.5) * COLS)
            sh = min(int(ROWS / ed), ROWS)
            sy = half - sh // 2

            # choose sprite char by HP and distance
            sprite = "@" if e.hp == 3 else ("M" if e.hp == 2 else "!")
            col_code = RE  # red

            for row in range(max(0, sy), min(ROWS, sy + sh)):
                if 0 <= sx < COLS and depth_buf[sx] > ed:
                    grid[row][sx] = (sprite, col_code)

        # ── Crosshair ─────────────────────────────────────────────────────────
        cx, cy = COLS // 2, ROWS // 2
        grid[cy][cx] = ("+", W)

        # ── Print frame ───────────────────────────────────────────────────────
        border_h = "+" + "─" * COLS + "+"
        print(d(border_h))
        for row in range(ROWS):
            line = "|"
            for col in range(COLS):
                ch, colour = grid[row][col]
                line += f"{colour}{ch}{R}"
            line += d("|")
            print(line)
        print(d(border_h))

    def render_minimap(self):
        """Small 2D minimap beside the HUD."""
        scale = 2          # map chars per map tile
        mw, mh = MAP_W, min(MAP_H, 8)
        top_row = max(0, int(self.py) - mh // 2)
        lines = []
        for my in range(top_row, min(MAP_H, top_row + mh)):
            row_str = ""
            for mx in range(MAP_W):
                t = MAP[my][mx]
                if abs(mx + 0.5 - self.px) < 0.6 and abs(my + 0.5 - self.py) < 0.6:
                    row_str += y("@")
                elif any(e.alive and int(e.x) == mx and int(e.y) == my
                         for e in self.enemies):
                    row_str += r("E")
                elif t == "#":
                    row_str += d("█")
                elif t == "K":
                    row_str += y("K")
                elif t == "X":
                    row_str += g("X")
                else:
                    row_str += d("·")
            lines.append(row_str)
        return lines

    def print_hud(self):
        # HP bar
        hp_w   = 20
        hp_f   = int(self.hp / 100 * hp_w)
        hp_col = G if self.hp > 60 else (Y if self.hp > 30 else RE)
        hp_bar = f"{hp_col}{'█' * hp_f}{D}{'░' * (hp_w - hp_f)}{R}"

        # compass direction
        dirs   = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
        di     = int((self.angle % (2 * math.pi)) / (2 * math.pi) * 8) % 8
        facing = dirs[di]

        minimap = self.render_minimap()

        print()
        print(f"  {w('[ FLUX DOOM ]')}  "
              f"HP [{hp_bar}] {self.hp:3d}   "
              f"AMMO: {g(str(self.ammo))}   "
              f"SCORE: {g(str(self.score))}   "
              f"KEY: {'[' + g('✓') + ']' if self.has_key else d('[×]')}   "
              f"FACING: {c(facing)}")
        print()

        # minimap + messages side by side
        map_lines  = minimap
        msg_lines  = self.msgs[-6:]

        combined = max(len(map_lines), len(msg_lines))
        for i in range(combined):
            ml = map_lines[i]  if i < len(map_lines)  else " " * MAP_W
            mg = msg_lines[i]  if i < len(msg_lines)  else ""
            print(f"  {ml}    {mg}")
        print()

        # controls
        alive_count = len(self.alive_enemies())
        print(d(f"  Turn {self.turn}  |  Enemies alive: {alive_count}  |  "
                f"W=fwd  S=back  A=left  D=right  F=shoot  Q=quit"))
        print()

    # ── Actions ───────────────────────────────────────────────────────────────
    MOVE_SPEED = 0.5
    ROT_STEP   = math.pi / 8   # 22.5° per turn

    def move_forward(self):
        nx = self.px + math.cos(self.angle) * self.MOVE_SPEED
        ny = self.py + math.sin(self.angle) * self.MOVE_SPEED
        if not is_wall(nx, self.py): self.px = nx
        if not is_wall(self.px, ny): self.py = ny
        self.msg(d("You move forward."))

    def move_back(self):
        nx = self.px - math.cos(self.angle) * self.MOVE_SPEED
        ny = self.py - math.sin(self.angle) * self.MOVE_SPEED
        if not is_wall(nx, self.py): self.px = nx
        if not is_wall(self.px, ny): self.py = ny
        self.msg(d("You step back."))

    def turn_left(self):
        self.angle -= self.ROT_STEP
        self.msg(d("You turn left."))

    def turn_right(self):
        self.angle += self.ROT_STEP
        self.msg(d("You turn right."))

    def shoot(self):
        if self.ammo <= 0:
            self.msg(r("*CLICK* — out of ammo!")); return

        self.ammo -= 1
        # find closest enemy in crosshair (within 15° and 10 units)
        best   = None
        best_d = 999
        for e in self.alive_enemies():
            ea = e.angle_from(self.px, self.py)
            da = abs((ea - self.angle + math.pi) % (2 * math.pi) - math.pi)
            ed = e.dist(self.px, self.py)
            if da < 0.22 and ed < 10 and ed < best_d:
                best, best_d = e, ed

        if best:
            best.hp -= 1
            if best.hp <= 0:
                best.alive = False
                self.score += 100
                self.msg(g(f"ENEMY #{best.idx} DOWN! +100pts"))
            else:
                self.msg(y(f"Hit enemy #{best.idx}! ({best.hp} HP left)"))
        else:
            self.msg(d("Shot fired — missed."))

    def check_tile(self):
        t = tile(self.px, self.py)
        if t == "K" and not self.has_key:
            self.has_key = True
            self.score  += 200
            self.msg(g("KEY PICKED UP! Find the exit!"))
        if t == "X":
            if self.has_key:
                self.won  = True
                self.msg(g("*** YOU REACHED THE EXIT — YOU WIN! ***"))
            else:
                self.msg(r("Door is locked — find the key first!"))

    def enemy_turn(self):
        """Enemies move and attack after the player acts."""
        for e in self.alive_enemies():
            e.step_toward(self.px, self.py)
            if e.dist(self.px, self.py) < 0.7:
                dmg = random.randint(5, 15)
                self.hp -= dmg
                self.msg(r(f"Enemy #{e.idx} hits you for {dmg} damage!"))
        if self.hp <= 0:
            self.hp   = 0
            self.dead = True

    def tick(self, key):
        """Process one player action + enemy turn."""
        self.turn += 1
        acted = True

        key = key.lower().strip()
        if   key == "w": self.move_forward()
        elif key == "s": self.move_back()
        elif key == "a": self.turn_left()
        elif key == "d": self.turn_right()
        elif key in ("f", " ", "shoot"): self.shoot()
        else:
            acted = False
            self.msg(r(f"Unknown key '{key}' — use W A S D F"))
            self.turn -= 1

        if acted:
            self.check_tile()
            self.enemy_turn()


# ── Main entry ────────────────────────────────────────────────────────────────
def run(kernel):
    # enable ANSI on Windows
    if os.name == "nt":
        os.system("color")
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
        except Exception:
            pass

    game = Game()

    # intro screen
    clrscr()
    print()
    print(red("  ██████╗  ██████╗  ██████╗ ███╗   ███╗"))
    print(red("  ██╔══██╗██╔═══██╗██╔═══██╗████╗ ████║"))
    print(red("  ██║  ██║██║   ██║██║   ██║██╔████╔██║"))
    print(red("  ██║  ██║██║   ██║██║   ██║██║╚██╔╝██║"))
    print(red("  ██████╔╝╚██████╔╝╚██████╔╝██║ ╚═╝ ██║"))
    print(red("  ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝     ╚═╝"))
    print()
    print(w("            FLUX EDITION  v2.0"))
    print()
    print(d("  Controls:"))
    print(f"    {g('W')} / {g('S')}  — move forward / back")
    print(f"    {g('A')} / {g('D')}  — turn left / right")
    print(f"    {g('F')}      — SHOOT")
    print(f"    {g('Q')}      — quit")
    print()
    print(d("  Find the KEY then reach the EXIT."))
    print(d("  Each command = one turn. Enemies move after you do."))
    print()
    print(d("  The minimap shows:  @ = you   E = enemy   K = key   X = exit"))
    print()
    try:
        input(y("  Press ENTER to start..."))
    except (EOFError, KeyboardInterrupt):
        return

    # main loop
    while not game.won and not game.dead:
        clrscr()
        game.render()
        game.print_hud()

        try:
            key = input(y("  > ")).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break

        if key.lower() in ("q", "quit", "exit"):
            break

        if not key:
            continue

        game.tick(key)

    # end screen
    clrscr()
    if game.won:
        print()
        print(g("  ██╗   ██╗ ██████╗ ██╗   ██╗    ██╗    ██╗██╗███╗   ██╗"))
        print(g("  ╚██╗ ██╔╝██╔═══██╗██║   ██║    ██║    ██║██║████╗  ██║"))
        print(g("   ╚████╔╝ ██║   ██║██║   ██║    ██║ █╗ ██║██║██╔██╗ ██║"))
        print(g("    ╚██╔╝  ██║   ██║██║   ██║    ██║███╗██║██║██║╚██╗██║"))
        print(g("     ██║   ╚██████╔╝╚██████╔╝    ╚███╔███╔╝██║██║ ╚████║"))
        print(g("     ╚═╝    ╚═════╝  ╚═════╝      ╚══╝╚══╝ ╚═╝╚═╝  ╚═══╝"))
        print()
        print(g(f"  Score: {game.score}   Turns: {game.turn}   Enemies killed: "
                f"{sum(1 for e in game.enemies if not e.alive)}"))
    elif game.dead:
        print()
        print(r("  ██╗   ██╗ ██████╗ ██╗   ██╗    ██████╗ ██╗███████╗██████╗"))
        print(r("  ╚██╗ ██╔╝██╔═══██╗██║   ██║    ██╔══██╗██║██╔════╝██╔══██╗"))
        print(r("   ╚████╔╝ ██║   ██║██║   ██║    ██║  ██║██║█████╗  ██║  ██║"))
        print(r("    ╚██╔╝  ██║   ██║██║   ██║    ██║  ██║██║██╔══╝  ██║  ██║"))
        print(r("     ██║   ╚██████╔╝╚██████╔╝    ██████╔╝██║███████╗██████╔╝"))
        print(r("     ╚═╝    ╚═════╝  ╚═════╝     ╚═════╝ ╚═╝╚══════╝╚═════╝"))
        print()
        print(r(f"  Score: {game.score}   Survived {game.turn} turns"))
    else:
        print()
        print(y("  Fled the battle."))
        print(y(f"  Score: {game.score}   Turns: {game.turn}"))

    print()
    try:
        input(d("  Press ENTER to return to Flux..."))
    except (EOFError, KeyboardInterrupt):
        pass
    print()
