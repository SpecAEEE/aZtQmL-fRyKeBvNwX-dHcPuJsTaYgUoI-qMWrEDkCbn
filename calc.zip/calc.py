"""
calc.py — expression calculator for Flux OS
fpt install calc
"""

MANIFEST = {
    "name":        "calc",
    "version":     "1.0.0",
    "description": "Interactive expression calculator with history",
    "commands":    ["calc"],
    "author":      "FluxTeam",
}

import math, re

# safe names exposed to eval
_SAFE = {k: getattr(math, k) for k in dir(math) if not k.startswith("_")}
_SAFE.update({
    "abs": abs, "round": round, "int": int, "float": float,
    "min": min, "max": max, "sum": sum, "pow": pow,
    "hex": hex, "bin": bin, "oct": oct,
})

_ANSI_R  = "\033[0m"
_ANSI_G  = "\033[92m"
_ANSI_C  = "\033[96m"
_ANSI_Y  = "\033[93m"
_ANSI_D  = "\033[2m"
_ANSI_RE = "\033[91m"

def _g(t): return f"{_ANSI_G}{t}{_ANSI_R}"
def _c(t): return f"{_ANSI_C}{t}{_ANSI_R}"
def _y(t): return f"{_ANSI_Y}{t}{_ANSI_R}"
def _d(t): return f"{_ANSI_D}{t}{_ANSI_R}"
def _r(t): return f"{_ANSI_RE}{t}{_ANSI_R}"


def _evaluate(expr: str, mem: dict) -> str:
    # replace ^ with ** for power
    expr = expr.replace("^", "**")

    # allow ans shorthand
    if "ans" in expr and "ans" in mem:
        expr = expr.replace("ans", str(mem["ans"]))

    # allow assignment: x = expr
    assign_match = re.match(r"^([a-zA-Z_]\w*)\s*=\s*(.+)$", expr)
    if assign_match:
        varname, valexpr = assign_match.groups()
        if varname in _SAFE:
            return _r(f"  cannot reassign built-in '{varname}'")
        env = dict(_SAFE)
        env.update(mem)
        result = eval(valexpr, {"__builtins__": {}}, env)  # noqa: S307
        mem[varname] = result
        mem["ans"] = result
        return _g(f"  {varname} = {result}")

    env = dict(_SAFE)
    env.update(mem)
    result = eval(expr, {"__builtins__": {}}, env)  # noqa: S307
    mem["ans"] = result

    # pretty print
    if isinstance(result, float) and result == int(result):
        result = int(result)
    return _g(f"  = {result}")


def run(kernel):
    mem = {}
    history = []

    print()
    print(_c("  FluxCalc 1.0  —  type an expression, 'help', or 'exit'"))
    print(_d("  " + "─" * 48))

    while True:
        try:
            line = input(_y("  calc> ")).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break

        if not line:
            continue

        if line in ("exit", "quit", "q"):
            break

        if line == "help":
            print(_d("  ─" * 24))
            print(_c("  Operators :") + "  + - * / // % ** ^")
            print(_c("  Functions :") + "  sin cos tan sqrt log log2 log10 ceil floor")
            print(_c("  Constants :") + "  pi e tau inf")
            print(_c("  Special   :") + "  ans  (last result)")
            print(_c("  Assign    :") + "  x = 42   (store variable)")
            print(_c("  History   :") + "  history")
            print(_c("  Bases     :") + "  hex(n)  bin(n)  oct(n)")
            print(_d("  ─" * 24))
            continue

        if line == "history":
            if not history:
                print(_d("  (no history)"))
            for i, (expr, res) in enumerate(history[-20:], 1):
                print(f"  {_d(str(i).rjust(3))}  {expr}  {_d(res)}")
            continue

        if line == "clear":
            mem.clear()
            print(_d("  memory cleared"))
            continue

        if line == "vars":
            user_vars = {k: v for k, v in mem.items() if k not in _SAFE and k != "ans"}
            if not user_vars:
                print(_d("  (no variables set)"))
            for k, v in user_vars.items():
                print(f"  {_g(k)} = {v}")
            continue

        try:
            result_str = _evaluate(line, mem)
            print(result_str)
            history.append((line, result_str.strip()))
        except ZeroDivisionError:
            print(_r("  Error: division by zero"))
        except Exception as e:
            print(_r(f"  Error: {e}"))

    print(_d("  calc: bye"))
    print()
