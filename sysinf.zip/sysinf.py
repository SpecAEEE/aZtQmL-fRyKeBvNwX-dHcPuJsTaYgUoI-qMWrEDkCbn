# ─────────────────────────────────────────────
#  sysinf 
#  Package: sysinf  Version: 1.0.0
#  Command: sysinf
# ─────────────────────────────────────────────

MANIFEST = {
    "name":        "sysinf",
    "version":     "1.0.0",
    "description": "Information Display",
    "author":      "Flux Project",
    "commands":    ["sysinf"],
}

import datetime
import time

# ANSI
_R  = "\033[0m"
_G  = "\033[92m"
_C  = "\033[96m"
_Y  = "\033[93m"
_B  = "\033[94m"
_D  = "\033[2m"
_W  = "\033[97m"
_M  = "\033[95m"
_BLD= "\033[1m"

def _c(s): return f"{_C}{s}{_R}"
def _g(s): return f"{_G}{s}{_R}"
def _y(s): return f"{_Y}{s}{_R}"
def _b(s): return f"{_B}{s}{_R}"
def _d(s): return f"{_D}{s}{_R}"
def _w(s): return f"{_W}{_BLD}{s}{_R}"
def _m(s): return f"{_M}{s}{_R}"

LOGO = [
    _g("  ███████╗██╗     ██╗   ██╗██╗  ██╗"),
    _g("  ██╔════╝██║     ██║   ██║╚██╗██╔╝"),
    _g("  █████╗  ██║     ██║   ██║ ╚███╔╝ "),
    _g("  ██╔══╝  ██║     ██║   ██║ ██╔██╗ "),
    _g("  ██║     ███████╗╚██████╔╝██╔╝ ██╗"),
    _g("  ╚═╝     ╚══════╝ ╚═════╝ ╚═╝  ╚═╝"),
    _d("       simulated operating system   "),
]

def _bar(pct, length=20, filled_col=_G, empty_col=_D):
    f = int(pct / 100 * length)
    return f"{filled_col}{'█'*f}{_R}{empty_col}{'░'*(length-f)}{_R}"

def run(kernel):
    cpu  = kernel.cpu
    mem  = kernel.memory
    stor = kernel.storage
    now  = datetime.datetime.now()
    uptime = kernel.uptime_str()

    num_parts = len(kernel.fs.volumes)
    num_pkgs  = len(kernel.installed_packages)
    num_procs = len(kernel.processes)

    # Build info lines
    sep = _d("─" * 28)
    info = [
        f"{_w(kernel.current_user)}{_d('@')}{_c('fluxt')}",
        sep,
        f"{_c('OS')}        Flux 0.1",
        f"{_c('Kernel')}    FluxKernel 0.1 x86_64",
        f"{_c('Shell')}     FluxShell",
        f"{_c('Uptime')}    {uptime}",
        f"{_c('Packages')}  {num_pkgs} (fpt)",
        f"{_c('Processes')} {num_procs} running",
        f"{_c('Partitions')} {num_parts}",
        sep,
        f"{_c('CPU')}       FluxCPU {cpu.clock_speed_mhz}GHz × {cpu.cores}",
        f"{_c('CPU Load')}  [{_bar(cpu.usage, 20)}] {cpu.usage:.1f}%",
        f"{_c('Memory')}    [{_bar(mem.used_pct, 20)}] {mem.used_mb:.1f}MB / {mem.size_mb}MB",
        f"{_c('Disk')}      [{_bar(stor.used_kb/(stor.size_mb*1024)*100, 20)}] {stor.used_kb}KB / {stor.size_mb}MB",
        sep,
        # colour palette blocks
        "  " + "".join(f"\033[4{i}m  {_R}" for i in range(8)),
    ]

    # Zip logo + info side by side
    logo_w = 43   # visible width of logo lines (no ANSI)
    lines  = max(len(LOGO), len(info))

    print()
    for i in range(lines):
        left  = LOGO[i]  if i < len(LOGO)  else " " * logo_w
        right = info[i]  if i < len(info)  else ""
        # pad left column (ANSI codes don't count toward width so add raw spaces)
        print(f"{left}   {right}")
    print()