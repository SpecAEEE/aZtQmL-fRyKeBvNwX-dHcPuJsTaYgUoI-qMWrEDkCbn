MANIFEST = {
    "name":        "fluxvm",
    "version":     "1.0.0",
    "description": "Fake Ubuntu 24.04 LTS VM with full Linux shell and apt",
    "author":      "Flux Project",
    "commands":    ["fluxvm"],
}

import os, sys, time, datetime, random, re, json, fnmatch

R  = "\033[0m"
G  = "\033[92m"; C = "\033[96m"; Y = "\033[93m"
RE = "\033[91m"; D = "\033[2m";  W = "\033[97m"; B = "\033[1m"
M  = "\033[95m"; BL = "\033[94m"

def g(t): return f"{G}{t}{R}"
def c(t): return f"{C}{t}{R}"
def y(t): return f"{Y}{t}{R}"
def r(t): return f"{RE}{t}{R}"
def d(t): return f"{D}{t}{R}"
def w(t): return f"{W}{t}{R}"
def bl(t): return f"{BL}{t}{R}"

APT_REPO = {
    "bash":           {"ver":"5.2.21","size":"1628 kB","desc":"The GNU Bourne Again SHell","deps":["libc6"]},
    "coreutils":      {"ver":"9.4","size":"7124 kB","desc":"GNU core utilities","deps":["libc6"]},
    "grep":           {"ver":"3.11","size":"328 kB","desc":"GNU grep, egrep and fgrep","deps":["libc6"]},
    "sed":            {"ver":"4.9","size":"316 kB","desc":"GNU stream editor","deps":["libc6"]},
    "gawk":           {"ver":"5.3.0","size":"1728 kB","desc":"GNU awk pattern scanning language","deps":["libc6"]},
    "findutils":      {"ver":"4.9.0","size":"1720 kB","desc":"Utilities for finding files","deps":["libc6"]},
    "tar":            {"ver":"1.35","size":"3280 kB","desc":"GNU tar archiving utility","deps":["libc6"]},
    "gzip":           {"ver":"1.12","size":"222 kB","desc":"GNU compression utilities","deps":["libc6"]},
    "bzip2":          {"ver":"1.0.8","size":"257 kB","desc":"Block-sorting file compressor","deps":["libc6"]},
    "xz-utils":       {"ver":"5.6.1","size":"536 kB","desc":"XZ-format compression utilities","deps":["libc6"]},
    "less":           {"ver":"643","size":"358 kB","desc":"Pager program similar to more","deps":["libc6"]},
    "vim":            {"ver":"9.1.0016","size":"3756 kB","desc":"Vi IMproved - enhanced vi editor","deps":["libc6"]},
    "nano":           {"ver":"7.2","size":"880 kB","desc":"Small, friendly text editor","deps":["libc6"]},
    "curl":           {"ver":"8.5.0","size":"624 kB","desc":"Command line tool for transferring data with URL syntax","deps":["libc6","libssl3"]},
    "wget":           {"ver":"1.21.4","size":"1288 kB","desc":"Retrieves files from the web","deps":["libc6"]},
    "git":            {"ver":"2.43.0","size":"20280 kB","desc":"Fast, scalable, distributed revision control system","deps":["libc6"]},
    "python3":        {"ver":"3.12.3","size":"626 kB","desc":"Interactive high-level object-oriented language","deps":[]},
    "python3-pip":    {"ver":"24.0","size":"1798 kB","desc":"Python package installer","deps":["python3"]},
    "python3-venv":   {"ver":"3.12.3","size":"6 kB","desc":"Python venv module","deps":["python3"]},
    "python3-dev":    {"ver":"3.12.3","size":"6 kB","desc":"Header files for Python","deps":["python3"]},
    "nodejs":         {"ver":"18.19.0","size":"29764 kB","desc":"JavaScript runtime built on V8","deps":["libc6"]},
    "npm":            {"ver":"9.2.0","size":"32824 kB","desc":"Node.js package manager","deps":["nodejs"]},
    "gcc":            {"ver":"13.2.0","size":"23432 kB","desc":"GNU C compiler","deps":["libc6"]},
    "g++":            {"ver":"13.2.0","size":"23476 kB","desc":"GNU C++ compiler","deps":["gcc"]},
    "make":           {"ver":"4.3","size":"496 kB","desc":"Utility for directing compilation","deps":["libc6"]},
    "cmake":          {"ver":"3.28.3","size":"27468 kB","desc":"Cross-platform build system","deps":["libc6"]},
    "build-essential":{"ver":"12.10ubuntu1","size":"4 kB","desc":"Informational list of build-essential packages","deps":["gcc","g++","make"]},
    "htop":           {"ver":"3.3.0","size":"472 kB","desc":"Interactive process viewer","deps":["libc6"]},
    "net-tools":      {"ver":"2.10","size":"456 kB","desc":"NET-3 networking toolkit","deps":["libc6"]},
    "openssh-client": {"ver":"9.6p1","size":"1396 kB","desc":"Secure Shell (SSH) client","deps":["libc6"]},
    "openssh-server": {"ver":"9.6p1","size":"592 kB","desc":"Secure Shell (SSH) server","deps":["openssh-client"]},
    "nginx":          {"ver":"1.24.0","size":"596 kB","desc":"Small, powerful, scalable web/proxy server","deps":["libc6"]},
    "apache2":        {"ver":"2.4.58","size":"540 kB","desc":"Apache HTTP Server","deps":["libc6"]},
    "mysql-server":   {"ver":"8.0.36","size":"28208 kB","desc":"MySQL database server","deps":["libc6"]},
    "postgresql":     {"ver":"16+262","size":"56 kB","desc":"Object-relational SQL database","deps":["libc6"]},
    "redis-server":   {"ver":"7.2.4","size":"2820 kB","desc":"Persistent key-value database","deps":["libc6"]},
    "sqlite3":        {"ver":"3.45.1","size":"1060 kB","desc":"Command line interface for SQLite 3","deps":["libc6"]},
    "docker.io":      {"ver":"24.0.7","size":"48264 kB","desc":"Linux container runtime","deps":["libc6"]},
    "ffmpeg":         {"ver":"6.1.1","size":"1872 kB","desc":"Tools for transcoding multimedia files","deps":["libc6"]},
    "rsync":          {"ver":"3.2.7","size":"428 kB","desc":"Fast, versatile file-copying tool","deps":["libc6"]},
    "tmux":           {"ver":"3.4","size":"700 kB","desc":"Terminal multiplexer","deps":["libc6"]},
    "screen":         {"ver":"4.9.1","size":"900 kB","desc":"Terminal multiplexer with VT100 emulation","deps":["libc6"]},
    "zip":            {"ver":"3.0","size":"320 kB","desc":"Archiver for .zip files","deps":["libc6"]},
    "unzip":          {"ver":"6.0","size":"392 kB","desc":"De-archiver for .zip files","deps":["libc6"]},
    "strace":         {"ver":"6.8","size":"3424 kB","desc":"System call tracer","deps":["libc6"]},
    "lsof":           {"ver":"4.95.0","size":"488 kB","desc":"Utility to list open files","deps":["libc6"]},
    "nmap":           {"ver":"7.94","size":"5948 kB","desc":"The Network Mapper","deps":["libc6"]},
    "tcpdump":        {"ver":"4.99.4","size":"1228 kB","desc":"Command-line network traffic analyzer","deps":["libc6"]},
    "iptables":       {"ver":"1.8.10","size":"4756 kB","desc":"Administration tools for packet filtering","deps":["libc6"]},
    "ufw":            {"ver":"0.36.2","size":"656 kB","desc":"Program for managing a Netfilter firewall","deps":["iptables"]},
    "fail2ban":       {"ver":"1.0.2","size":"568 kB","desc":"Ban hosts causing authentication errors","deps":["python3"]},
    "cron":           {"ver":"3.0pl1","size":"232 kB","desc":"Process scheduling daemon","deps":["libc6"]},
    "sudo":           {"ver":"1.9.15p5","size":"2552 kB","desc":"Limited super user privileges","deps":["libc6"]},
    "jq":             {"ver":"1.7.1","size":"576 kB","desc":"Lightweight command-line JSON processor","deps":["libc6"]},
    "tree":           {"ver":"2.1.1","size":"172 kB","desc":"Displays an indented directory tree","deps":["libc6"]},
    "neofetch":       {"ver":"7.1.0","size":"100 kB","desc":"Fast, customizable system info script","deps":["bash"]},
    "neovim":         {"ver":"0.9.5","size":"13728 kB","desc":"Heavily refactored vim fork","deps":["libc6"]},
    "zsh":            {"ver":"5.9","size":"2712 kB","desc":"Shell with lots of features","deps":["libc6"]},
    "fish":           {"ver":"3.7.0","size":"8888 kB","desc":"Friendly interactive shell","deps":["libc6"]},
    "ruby":           {"ver":"3.2.3","size":"30 kB","desc":"Interpreter of object-oriented scripting language Ruby","deps":["libc6"]},
    "golang-go":      {"ver":"1.22.1","size":"87756 kB","desc":"Go programming language compiler","deps":["libc6"]},
    "rustc":          {"ver":"1.80.1","size":"286968 kB","desc":"Rust systems programming language","deps":["gcc"]},
    "perl":           {"ver":"5.38.2","size":"256 kB","desc":"Larry Wall's Practical Extraction and Report Language","deps":["libc6"]},
    "php":            {"ver":"8.3","size":"16 kB","desc":"Server-side HTML-embedded scripting language","deps":["libc6"]},
    "nginx":          {"ver":"1.24.0","size":"596 kB","desc":"Lightweight web/proxy server","deps":["libc6"]},
    "certbot":        {"ver":"2.10.0","size":"60 kB","desc":"Automatically configure HTTPS via Let's Encrypt","deps":["python3"]},
    "ansible":        {"ver":"9.3.0","size":"30040 kB","desc":"Radically simple IT automation","deps":["python3"]},
    "gh":             {"ver":"2.47.0","size":"14272 kB","desc":"GitHub CLI","deps":["git"]},
    "fzf":            {"ver":"0.52.0","size":"3528 kB","desc":"General-purpose command-line fuzzy finder","deps":["libc6"]},
    "bat":            {"ver":"0.24.0","size":"3024 kB","desc":"A cat clone with syntax highlighting","deps":["libc6"]},
    "ripgrep":        {"ver":"14.1.0","size":"3092 kB","desc":"Recursively search directories for a regex pattern","deps":["libc6"]},
    "tldr":           {"ver":"3.3.0","size":"28 kB","desc":"Collaborative cheatsheets for console commands","deps":["python3"]},
    "ncdu":           {"ver":"1.20","size":"160 kB","desc":"NCurses-based disk usage viewer","deps":["libc6"]},
    "sysstat":        {"ver":"12.7.4","size":"1168 kB","desc":"System performance tools for Linux","deps":["libc6"]},
    "iotop":          {"ver":"0.6","size":"80 kB","desc":"Simple top-like I/O monitor","deps":["python3"]},
    "dnsutils":       {"ver":"9.18.24","size":"612 kB","desc":"Clients provided with BIND","deps":["libc6"]},
    "mtr":            {"ver":"0.95","size":"344 kB","desc":"Full screen traceroute tool","deps":["libc6"]},
    "whois":          {"ver":"5.5.22","size":"216 kB","desc":"Intelligent WHOIS client","deps":["libc6"]},
    "traceroute":     {"ver":"2.1.5","size":"148 kB","desc":"Traces the route taken by packets","deps":["libc6"]},
    "libssl-dev":     {"ver":"3.0.13","size":"4152 kB","desc":"Secure Sockets Layer toolkit - development files","deps":["libc6"]},
    "libpq-dev":      {"ver":"16.2","size":"1456 kB","desc":"Header files for libpq5 (PostgreSQL library)","deps":["libc6"]},
    "mongodb":        {"ver":"7.0.4","size":"145808 kB","desc":"Object/document-oriented database","deps":["libc6"]},
    "kubectl":        {"ver":"1.29.3","size":"49576 kB","desc":"Kubernetes command-line tool","deps":["libc6"]},
    "helm":           {"ver":"3.14.3","size":"16556 kB","desc":"Kubernetes package manager","deps":[]},
    "terraform":      {"ver":"1.7.5","size":"86932 kB","desc":"Infrastructure as Code software tool","deps":["libc6"]},
    "imagemagick":    {"ver":"6.9.13.12","size":"264 kB","desc":"Image manipulation programs","deps":["libc6"]},
    "htpasswd":       {"ver":"2.4.58","size":"168 kB","desc":"Apache HTTP authentication tools","deps":["libc6"]},
    "logrotate":      {"ver":"3.21.0","size":"208 kB","desc":"Log rotation utility","deps":["libc6"]},
    "acl":            {"ver":"2.3.2","size":"204 kB","desc":"Access control list utilities","deps":["libc6"]},
    "java-21-openjdk":{"ver":"21.0.3","size":"203244 kB","desc":"OpenJDK Development Kit 21","deps":["libc6"]},
    "composer":       {"ver":"2.7.2","size":"1748 kB","desc":"Dependency Manager for PHP","deps":["php"]},
    "lua5.4":         {"ver":"5.4.6","size":"338 kB","desc":"Powerful, lightweight scripting language","deps":["libc6"]},
}

FLUXVM_STATE_PATH = "/private/var/db/packages/fluxvm_state.json"

DEFAULT_FS = {
    "/": {"type":"dir"}, "/bin": {"type":"dir"}, "/boot": {"type":"dir"},
    "/dev": {"type":"dir"}, "/etc": {"type":"dir"}, "/etc/apt": {"type":"dir"},
    "/etc/apt/sources.list.d": {"type":"dir"}, "/etc/ssh": {"type":"dir"},
    "/etc/network": {"type":"dir"}, "/home": {"type":"dir"},
    "/home/user": {"type":"dir"}, "/lib": {"type":"dir"}, "/lib64": {"type":"dir"},
    "/media": {"type":"dir"}, "/mnt": {"type":"dir"}, "/opt": {"type":"dir"},
    "/proc": {"type":"dir"}, "/root": {"type":"dir"}, "/run": {"type":"dir"},
    "/sbin": {"type":"dir"}, "/srv": {"type":"dir"}, "/sys": {"type":"dir"},
    "/tmp": {"type":"dir"}, "/usr": {"type":"dir"}, "/usr/bin": {"type":"dir"},
    "/usr/lib": {"type":"dir"}, "/usr/local": {"type":"dir"},
    "/usr/local/bin": {"type":"dir"}, "/usr/share": {"type":"dir"},
    "/usr/share/doc": {"type":"dir"}, "/var": {"type":"dir"},
    "/var/log": {"type":"dir"}, "/var/cache": {"type":"dir"},
    "/var/cache/apt": {"type":"dir"}, "/var/cache/apt/archives": {"type":"dir"},
    "/var/lib": {"type":"dir"}, "/var/lib/apt": {"type":"dir"},
    "/var/lib/apt/lists": {"type":"dir"}, "/var/lib/dpkg": {"type":"dir"},
    "/var/lib/dpkg/info": {"type":"dir"}, "/var/tmp": {"type":"dir"},
    "/var/log/apt": {"type":"dir"},
    "/etc/hostname":    {"type":"file","content":"fluxvm\n","mode":"644"},
    "/etc/os-release":  {"type":"file","mode":"644","content":
        'NAME="Ubuntu"\nVERSION="24.04 LTS (Noble Numbat)"\nID=ubuntu\n'
        'PRETTY_NAME="Ubuntu 24.04 LTS"\nVERSION_ID="24.04"\n'
        'HOME_URL="https://www.ubuntu.com/"\nUBUNTU_CODENAME=noble\n'},
    "/etc/passwd":      {"type":"file","mode":"644","content":
        "root:x:0:0:root:/root:/bin/bash\n"
        "daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n"
        "www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\n"
        "user:x:1000:1000:Ubuntu User,,,:/home/user:/bin/bash\n"},
    "/etc/hosts":       {"type":"file","mode":"644","content":
        "127.0.0.1 localhost\n127.0.1.1 fluxvm\n::1 localhost ip6-localhost\n"},
    "/etc/fstab":       {"type":"file","mode":"644","content":
        "/dev/sda1 / ext4 errors=remount-ro 0 1\n/dev/sda2 none swap sw 0 0\n"},
    "/etc/apt/sources.list": {"type":"file","mode":"644","content":
        "deb http://archive.ubuntu.com/ubuntu noble main restricted universe multiverse\n"
        "deb http://archive.ubuntu.com/ubuntu noble-updates main restricted universe multiverse\n"
        "deb http://security.ubuntu.com/ubuntu noble-security main restricted universe multiverse\n"},
    "/etc/ssh/sshd_config": {"type":"file","mode":"640","content":
        "Port 22\nPermitRootLogin prohibit-password\nPasswordAuthentication yes\n"},
    "/etc/network/interfaces": {"type":"file","mode":"644","content":
        "auto lo\niface lo inet loopback\nauto eth0\niface eth0 inet dhcp\n"},
    "/root/.bashrc":    {"type":"file","mode":"644","content":
        "export PS1='\\u@\\h:\\w\\$ '\nexport PATH=$PATH:/usr/local/bin\n"
        "alias ll='ls -la'\nalias la='ls -A'\nalias l='ls -CF'\n"},
    "/root/.bash_history": {"type":"file","mode":"600","content":
        "apt update\napt upgrade\nls -la\ncd /etc\ncat hosts\nuname -a\ndf -h\nfree -h\n"},
    "/home/user/.bashrc": {"type":"file","mode":"644","content":
        "export PS1='\\u@\\h:\\w\\$ '\nalias ll='ls -la'\n"},
    "/var/log/syslog":  {"type":"file","mode":"640","content":
        "Mar 12 00:00:01 fluxvm systemd[1]: Started Session 1 of User root.\n"
        "Mar 12 00:00:03 fluxvm sshd[892]: Server listening on 0.0.0.0 port 22.\n"},
    "/var/log/auth.log": {"type":"file","mode":"640","content":
        "Mar 12 00:00:05 fluxvm sshd[892]: Accepted publickey for root from 127.0.0.1\n"},
    "/var/log/apt/history.log": {"type":"file","mode":"644","content":""},
    "/proc/cpuinfo":    {"type":"virtual","content":
        "processor\t: 0\nmodel name\t: FluxCPU 3.20GHz\ncpu MHz\t\t: 3200.000\n"
        "processor\t: 1\nmodel name\t: FluxCPU 3.20GHz\ncpu MHz\t\t: 3200.000\n"},
    "/proc/meminfo":    {"type":"virtual"},
    "/proc/version":    {"type":"virtual","content":
        "Linux version 6.8.0-47-generic (buildd@lcy02-amd64-059) "
        "(gcc (Ubuntu 13.2.0-23ubuntu4) 13.2.0) #47-Ubuntu SMP PREEMPT_DYNAMIC\n"},
    "/proc/uptime":     {"type":"virtual"},
    "/sys/class/net/eth0/address": {"type":"virtual","content":"52:54:00:12:34:56\n"},
}


class VMState:
    def __init__(self, kernel):
        self.kernel    = kernel
        self.fs        = {}
        self.installed = {}
        self.env = {
            "HOME": "/root", "USER": "root", "SHELL": "/bin/bash",
            "TERM": "xterm-256color", "LANG": "en_US.UTF-8",
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "HOSTNAME": "fluxvm",
        }
        self.aliases   = {"ll":"ls -la","la":"ls -A","l":"ls -CF"}
        self.cwd       = "/root"
        self.user      = "root"
        self.boot_time = time.time()
        self._load()

    def _save(self):
        data = json.dumps({"fs":self.fs,"installed":self.installed,
                           "env":self.env,"aliases":self.aliases}, indent=2)
        self.kernel.fs.create_file("MainPartition", FLUXVM_STATE_PATH, content=data)

    def _load(self):
        ok, content = self.kernel.fs.read_file("MainPartition", FLUXVM_STATE_PATH)
        if ok and content:
            try:
                data = json.loads(content)
                self.fs = data.get("fs", {}); self.installed = data.get("installed", {})
                self.env = {**self.env, **data.get("env", {})}
                self.aliases = {**self.aliases, **data.get("aliases", {})}
                return
            except Exception: pass
        self.fs = dict(DEFAULT_FS); self._save()

    def resolve(self, path):
        if not path or path == "~": return self.env.get("HOME", "/root")
        if path.startswith("~"): path = self.env.get("HOME", "/root") + path[1:]
        if not path.startswith("/"): path = self.cwd.rstrip("/") + "/" + path
        parts = []
        for p in path.split("/"):
            if p == "..":
                if parts: parts.pop()
            elif p and p != ".": parts.append(p)
        return "/" + "/".join(parts)

    def exists(self, path): return path in self.fs
    def is_dir(self, path):  return self.fs.get(path, {}).get("type") == "dir"
    def is_file(self, path): return self.fs.get(path, {}).get("type") in ("file","virtual")

    def ls_dir(self, path):
        path = path.rstrip("/"); seen = set()
        for p in self.fs:
            if p == path or not p.startswith(path + "/"): continue
            top = p[len(path)+1:].split("/")[0]
            if top: seen.add(top)
        return sorted(seen)

    def read(self, path):
        node = self.fs.get(path, {})
        if node.get("type") == "virtual": return self._virtual(path)
        return node.get("content", "")

    def _virtual(self, path):
        if path == "/proc/meminfo":
            return ("MemTotal:       65536000 kB\nMemFree:        57344000 kB\n"
                    "MemAvailable:   57344000 kB\nSwapTotal:      2097152 kB\nSwapFree: 2097152 kB\n")
        if path == "/proc/uptime":
            up = time.time() - self.boot_time
            return f"{up:.2f} {up*0.9:.2f}\n"
        return self.fs.get(path, {}).get("content", "")

    def write(self, path, content, append=False):
        parent = path.rsplit("/", 1)[0] or "/"
        if parent not in self.fs: self.fs[parent] = {"type":"dir"}
        existing = self.fs[path].get("content","") if append and path in self.fs else ""
        self.fs[path] = {"type":"file","content":existing+content,"mode":"644",
                         "mtime":datetime.datetime.now().isoformat()}
        self._save()

    def mkdir(self, path):
        self.fs[path] = {"type":"dir","mtime":datetime.datetime.now().isoformat()}
        self._save()

    def rm(self, path, recursive=False):
        keys = [p for p in self.fs if p == path or (recursive and p.startswith(path+"/"))]
        for k in keys: self.fs.pop(k, None)
        self._save()

    def mv(self, src, dst):
        for p in list(self.fs.keys()):
            if p == src or p.startswith(src+"/"):
                self.fs[dst + p[len(src):]] = self.fs.pop(p)
        self._save()

    def cp(self, src, dst):
        import copy
        for p in list(self.fs.keys()):
            if p == src or p.startswith(src+"/"):
                self.fs[dst + p[len(src):]] = copy.deepcopy(self.fs[p])
        self._save()

    def mark_installed(self, name, ver):
        self.installed[name] = {"ver":ver,"date":datetime.datetime.now().isoformat()}
        self.fs[f"/usr/bin/{name}"]  = {"type":"file","content":f"[{name} binary]","mode":"755"}
        self.fs[f"/var/lib/dpkg/info/{name}.list"] = {"type":"file","mode":"644","content":f"/usr/bin/{name}\n"}
        self._save()

    def mark_removed(self, name):
        self.installed.pop(name, None)
        self.fs.pop(f"/usr/bin/{name}", None)
        self.fs.pop(f"/var/lib/dpkg/info/{name}.list", None)
        self._save()

    def get_mode(self, path):  return self.fs.get(path,{}).get("mode","644")
    def get_mtime(self, path):
        raw = self.fs.get(path,{}).get("mtime","")
        try:
            return datetime.datetime.fromisoformat(raw).strftime("%b %d %H:%M") if raw else "Jan  1 00:00"
        except: return "Jan  1 00:00"

class FluxVMShell:
    def __init__(self, state):
        self.state        = state
        self.running      = True
        self.history      = []
        self._apt_updated = False

    def prompt(self):
        cwd  = self.state.cwd
        home = self.state.env.get("HOME", "/root")
        cwd_disp = "~" + cwd[len(home):] if cwd.startswith(home) else cwd
        sym  = "#" if self.state.user == "root" else "$"
        ucol = r if self.state.user == "root" else g
        return f"{ucol(self.state.user+'@fluxvm')}:{bl(cwd_disp)}{W}{sym}{R} "

    def out(self, t=""): print(t)
    def err(self, t):    print(r(f"bash: {t}"))

    # ── REPL ──────────────────────────────────────────────────────────────────

    def run(self):
        while self.running:
            try:
                line = input(self.prompt()).strip()
            except (EOFError, KeyboardInterrupt):
                print(); break
            if not line: continue
            self.history.append(line)
            self._exec(line)

    def _exec(self, line):
        parts = line.split()
        if parts and parts[0] in self.state.aliases:
            line = self.state.aliases[parts[0]] + (" " + " ".join(parts[1:]) if len(parts)>1 else "")

        # output redirect
        for sep, append in [(" >> ", True), (" > ", False)]:
            if sep in line:
                left, dest = line.split(sep, 1)
                buf = self._single(left.strip(), None, capture=True)
                if buf: self.state.write(self.state.resolve(dest.strip()), buf+"\n", append=append)
                return

        # pipes
        if "|" in line:
            buf = None
            for seg in [s.strip() for s in line.split("|")]:
                buf = self._single(seg, buf, capture=True)
            if buf is not None: print(buf)
            return

        # env assignment
        if "=" in line and len(line.split()) == 1:
            k, v = line.split("=", 1)
            self.state.env[k.strip()] = v.strip().strip('"').strip("'")
            return

        self._single(line, None, capture=False)

    def _single(self, line, pipe_input, capture=False):
        parts = line.split()
        if not parts: return None
        cmd, args = parts[0], parts[1:]
        args = [re.sub(r'\$\{(\w+)\}|\$(\w+)',
                       lambda m: self.state.env.get(m.group(1) or m.group(2), ""), a)
                for a in args]
        lines_out = []
        def op(t=""):
            if capture: lines_out.append(str(t))
            else: print(t)
        result = self._cmd(cmd, args, pipe_input, op)
        if capture: return "\n".join(lines_out) if lines_out else result
        return result

    # ── Command dispatcher ────────────────────────────────────────────────────

    def _cmd(self, cmd, args, pipe_in, op):
        st = self.state
        fs = st.fs

        # ── builtins ─────────────────────────────────────────────────────────
        if cmd in ("exit","logout"): self.running = False; return None

        if cmd == "cd":
            p = st.resolve(args[0] if args else st.env.get("HOME","/root"))
            if st.is_dir(p): st.cwd = p; st.env["PWD"] = p
            else: op(r(f"bash: cd: {args[0] if args else '~'}: No such file or directory"))
            return None

        if cmd == "pwd": op(st.cwd); return st.cwd

        if cmd == "echo":
            a = args[:]
            newline = True
            if a and a[0] == "-n": newline = False; a = a[1:]
            t = " ".join(a)
            if newline: op(t)
            else: print(t, end="")
            return t

        if cmd == "export":
            for a in args:
                if "=" in a:
                    k,v = a.split("=",1); st.env[k] = v.strip('"').strip("'")
            return None

        if cmd == "unset":
            for a in args: st.env.pop(a, None)
            return None

        if cmd == "alias":
            if not args:
                for k,v in st.aliases.items(): op(f"alias {k}='{v}'")
                return None
            for a in args:
                if "=" in a:
                    k,v = a.split("=",1); st.aliases[k] = v.strip("'\"")
            st._save(); return None

        if cmd in ("source","."): 
            if args:
                for ln in st.read(st.resolve(args[0])).splitlines(): self._exec(ln.strip())
            return None

        if cmd == "history":
            for i,h in enumerate(self.history,1): op(f"  {str(i).rjust(4)}  {h}")
            return None

        if cmd == "clear": os.system("cls" if os.name=="nt" else "clear"); return None

        if cmd == "help":
            op(c("FluxVM — Ubuntu 24.04 LTS  (type 'exit' to return to Flux)"))
            op(d("─"*56))
            sections = [
                ("Files",   "ls cd pwd cat less head tail cp mv rm mkdir touch chmod ln stat file du df"),
                ("Text",    "grep sed awk sort uniq cut tr wc diff tee echo printf"),
                ("Search",  "find locate which whereis type"),
                ("Process", "ps top kill jobs watch nohup"),
                ("System",  "uname hostname uptime date cal whoami id env lscpu lsblk dmesg journalctl free"),
                ("Network", "ping curl wget ssh netstat ss ip ifconfig nslookup dig traceroute nmap"),
                ("Package", "apt apt-get dpkg pip pip3"),
                ("Archive", "tar gzip gunzip zip unzip xz"),
                ("Shell",   "echo export alias source history clear sudo su man sleep read xargs seq"),
                ("Misc",    "neofetch vim nano htop strace lsof bc crontab"),
            ]
            for sec, names in sections:
                op(f"  {y(sec)}: {d(names)}")
            op()
            return None

        # ── filesystem ────────────────────────────────────────────────────────

        if cmd == "ls":
            flags  = "".join(a[1:] for a in args if a.startswith("-"))
            paths  = [a for a in args if not a.startswith("-")] or [st.cwd]
            long_  = "l" in flags; all_  = "a" in flags
            human_ = "h" in flags; rev_  = "r" in flags
            for path in paths:
                path = st.resolve(path)
                if st.is_dir(path):
                    names = ([".", ".."] if all_ else []) + st.ls_dir(path)
                    if rev_: names.reverse()
                    if not long_:
                        row = []
                        for n in names:
                            fp = (path.rstrip("/")+"/"+n).replace("//","/")
                            row.append(c(n+"/") if st.is_dir(fp) else g(n))
                        op("  ".join(row))
                    else:
                        op(f"total {len(names)}")
                        for n in names:
                            fp    = (path.rstrip("/")+"/"+n).replace("//","/")
                            is_d  = st.is_dir(fp)
                            mode  = ("d" if is_d else "-") + self._mode_str(st.get_mode(fp))
                            sz    = len(st.read(fp).encode()) if not is_d else 0
                            sz_s  = self._human(sz) if human_ else str(sz)
                            mtime = st.get_mtime(fp)
                            owner = st.user
                            name_col = c(n+"/") if is_d else g(n)
                            op(f"{d(mode)} {d('1')} {d(owner)} {d(owner)} {sz_s:>8}  {d(mtime)}  {name_col}")
                elif st.is_file(path): op(g(path))
                else: op(r(f"ls: cannot access '{path}': No such file or directory"))
            return None

        if cmd == "cat":
            if pipe_in is not None: op(pipe_in); return pipe_in
            if not args: op(r("cat: missing operand")); return None
            parts_ = []
            for p in args:
                fp = st.resolve(p)
                if not st.is_file(fp): op(r(f"cat: {p}: No such file or directory")); continue
                content = st.read(fp); parts_.append(content); op(content)
            return "\n".join(parts_)

        if cmd in ("less","more"):
            content = pipe_in or (st.read(st.resolve(args[0])) if args and st.is_file(st.resolve(args[0])) else "")
            lines_ = content.splitlines(); page = 24
            for i in range(0, len(lines_), page):
                for ln in lines_[i:i+page]: op(ln)
                if i+page < len(lines_):
                    try:
                        k = input(d("  -- (q)uit / ENTER for more -- ")).strip().lower()
                        if k == "q": break
                    except: break
            return None

        if cmd == "head":
            n = 10
            if "-n" in args:
                try: n = int(args[args.index("-n")+1])
                except: pass
            content = pipe_in or (st.read(st.resolve([a for a in args if not a.startswith("-")][-1])) if args else "")
            for ln in (content or "").splitlines()[:n]: op(ln)
            return None

        if cmd == "tail":
            n = 10
            if "-n" in args:
                try: n = int(args[args.index("-n")+1])
                except: pass
            content = pipe_in or (st.read(st.resolve([a for a in args if not a.startswith("-")][-1])) if args else "")
            for ln in (content or "").splitlines()[-n:]: op(ln)
            return None

        if cmd == "touch":
            for p in args:
                fp = st.resolve(p)
                if not st.exists(fp): st.write(fp,"")
                else:
                    st.fs[fp]["mtime"] = datetime.datetime.now().isoformat()
                    st._save()
            return None

        if cmd == "mkdir":
            rec = "-p" in args
            for p in [a for a in args if not a.startswith("-")]:
                fp = st.resolve(p)
                if rec:
                    parts_ = fp.split("/")
                    for i in range(1, len(parts_)+1):
                        pp = "/".join(parts_[:i]) or "/"
                        if not st.exists(pp): st.mkdir(pp)
                else:
                    if st.exists(fp): op(r(f"mkdir: cannot create directory '{p}': File exists"))
                    else: st.mkdir(fp)
            return None

        if cmd == "rm":
            rec = any(f in args for f in ("-r","-rf","-fr","-R"))
            frc = any(f in args for f in ("-f","-rf","-fr"))
            for p in [a for a in args if not a.startswith("-")]:
                fp = st.resolve(p)
                if not st.exists(fp):
                    if not frc: op(r(f"rm: cannot remove '{p}': No such file or directory"))
                    continue
                if st.is_dir(fp) and not rec: op(r(f"rm: cannot remove '{p}': Is a directory")); continue
                st.rm(fp, recursive=rec)
            return None

        if cmd == "cp":
            ps = [a for a in args if not a.startswith("-")]
            if len(ps)<2: op(r("cp: missing destination")); return None
            src,dst = st.resolve(ps[0]),st.resolve(ps[1])
            if not st.exists(src): op(r(f"cp: '{ps[0]}': No such file or directory")); return None
            st.cp(src,dst); return None

        if cmd == "mv":
            ps = [a for a in args if not a.startswith("-")]
            if len(ps)<2: op(r("mv: missing destination")); return None
            src,dst = st.resolve(ps[0]),st.resolve(ps[1])
            if not st.exists(src): op(r(f"mv: '{ps[0]}': No such file or directory")); return None
            st.mv(src,dst); return None

        if cmd == "chmod":
            if len(args)<2: op(r("chmod: missing operand")); return None
            fp = st.resolve(args[1])
            if st.exists(fp): st.fs[fp]["mode"]=args[0]; st._save()
            else: op(r(f"chmod: cannot access '{args[1]}': No such file or directory"))
            return None

        if cmd == "chown": return None  # accepted, silently ignored

        if cmd == "ln":
            ps = [a for a in args if not a.startswith("-")]
            if len(ps)<2: return None
            src,dst = st.resolve(ps[0]),st.resolve(ps[1])
            st.fs[dst] = {"type":"symlink","target":src,"mode":"777"}; st._save()
            return None

        if cmd == "stat":
            if not args: return None
            fp = st.resolve(args[0])
            if not st.exists(fp): op(r(f"stat: cannot statx '{args[0]}': No such file or directory")); return None
            sz = len(st.read(fp).encode()) if st.is_file(fp) else 0
            op(f"  File: {fp}")
            op(f"  Size: {sz}\t\tBlocks: {sz//512+1}\tIO Block: 4096  {'directory' if st.is_dir(fp) else 'regular file'}")
            op(f"  Uid: (0/root)\tGid: (0/root)")
            op(f"  Modify: {st.get_mtime(fp)}")
            return None

        if cmd == "file":
            for p in args:
                fp = st.resolve(p)
                if not st.exists(fp): op(r(f"{p}: cannot open")); continue
                if st.is_dir(fp): op(f"{p}: directory")
                else:
                    content = st.read(fp)
                    if content.startswith("#!"): op(f"{p}: script, ASCII text executable")
                    else: op(f"{p}: ASCII text")
            return None

        if cmd == "du":
            human_ = "-h" in args
            for p in ([a for a in args if not a.startswith("-")] or [st.cwd]):
                fp = st.resolve(p)
                total = sum(len(st.fs[pp].get("content","").encode()) for pp in st.fs if pp.startswith(fp) and st.is_file(pp))
                op(f"{self._human(total) if human_ else total//1024}\t{fp}")
            return None

        if cmd == "df":
            human_ = "-h" in args
            sz = 20*1024*1024*1024; used = sum(len(n.get("content","").encode()) for n in st.fs.values() if n.get("type")=="file")
            free_ = sz-used; pct = int(used/sz*100)
            op(f"{'Filesystem':<20} {'Size':>6} {'Used':>6} {'Avail':>6} {'Use%':>4} Mounted")
            if human_:
                op(f"{'/dev/sda1':<20} {self._human(sz):>6} {self._human(used):>6} {self._human(free_):>6} {pct:>3}% /")
                op(f"{'tmpfs':<20} {'256M':>6} {'2.0M':>6} {'254M':>6} {'1%':>4} /tmp")
            else:
                op(f"{'/dev/sda1':<20} {sz//1024:>6} {used//1024:>6} {free_//1024:>6} {pct:>3}% /")
            return None

        # ── text processing ───────────────────────────────────────────────────

        if cmd == "grep":
            flags_   = "".join(a[1:] for a in args if a.startswith("-"))
            nonflags = [a for a in args if not a.startswith("-")]
            if not nonflags: op(r("grep: missing pattern")); return None
            pat = nonflags[0]; in_files = nonflags[1:]
            invert_  = "v" in flags_; icase_ = "i" in flags_
            lnum_    = "n" in flags_; cnt_   = "c" in flags_
            quiet_   = "q" in flags_; rec_   = "r" in flags_ or "R" in flags_
            sources  = {}
            if pipe_in is not None: sources["(stdin)"] = pipe_in
            elif in_files:
                for fp in in_files:
                    rp = st.resolve(fp)
                    if st.is_dir(rp) and rec_:
                        for pp in st.fs:
                            if pp.startswith(rp) and st.is_file(pp): sources[pp] = st.read(pp)
                    elif st.is_file(rp): sources[fp] = st.read(rp)
                    else: op(r(f"grep: {fp}: No such file or directory"))
            re_flags = re.IGNORECASE if icase_ else 0
            try: compiled = re.compile(pat, re_flags)
            except: compiled = re.compile(re.escape(pat), re_flags)
            out_lines = []; total = 0
            for fname, content in sources.items():
                hits = 0
                for i, line in enumerate(content.splitlines(), 1):
                    match = bool(compiled.search(line))
                    if invert_: match = not match
                    if match:
                        hits += 1; total += 1
                        if not cnt_ and not quiet_:
                            prefix = (c(fname)+":") if len(sources)>1 else ""
                            if lnum_: prefix += y(str(i))+":"
                            highlighted = compiled.sub(lambda m: g(m.group(0)), line)
                            out_lines.append(prefix+highlighted)
                if cnt_: out_lines.append(f"{fname}:{hits}" if len(sources)>1 else str(hits))
            if not quiet_:
                for ln in out_lines: op(ln)
            return "\n".join(out_lines)

        if cmd == "sed":
            content = pipe_in
            if not content:
                fps = [a for a in args if not a.startswith("s") and st.exists(st.resolve(a))]
                if fps: content = st.read(st.resolve(fps[-1]))
            if not content: return None
            result = content
            for expr in args:
                if expr.startswith("s"):
                    try:
                        sep = expr[1]; parts_ = expr.split(sep)
                        if len(parts_) >= 3:
                            pat2,repl,flags_ = parts_[1],parts_[2],(parts_[3] if len(parts_)>3 else "")
                            result = re.sub(pat2, repl, result, count=0 if "g" in flags_ else 1,
                                            flags=re.IGNORECASE if "i" in flags_ else 0)
                    except: pass
            op(result); return result

        if cmd == "awk":
            content = pipe_in
            if not content:
                fps = [a for a in args if not a.startswith("{") and st.exists(st.resolve(a))]
                if fps: content = st.read(st.resolve(fps[-1]))
            if not content: return None
            out_lines = []; prog = " ".join(args)
            for i, line in enumerate(content.splitlines(), 1):
                fields = line.split()
                def _sub(m):
                    e = m.group(1).strip()
                    if e=="NR": return str(i)
                    if e=="NF": return str(len(fields))
                    if e in ("0",""): return line
                    try: return fields[int(e)-1] if 0<int(e)<=len(fields) else ""
                    except: return e
                pm = re.search(r'print\s+(.*?)(?:}|$)', prog)
                if pm:
                    expr = re.sub(r'\$(\w+)', _sub, pm.group(1).strip())
                    expr = re.sub(r'\bNR\b', str(i), expr).replace("NF", str(len(fields)))
                    op(expr); out_lines.append(expr)
            return "\n".join(out_lines)

        if cmd == "sort":
            content = pipe_in or (st.read(st.resolve([a for a in args if not a.startswith("-")][-1])) if [a for a in args if not a.startswith("-")] else "")
            if not content: return None
            rev_ = "-r" in args; num_ = "-n" in args; uniq_ = "-u" in args
            lines_ = content.splitlines()
            try: lines_.sort(key=lambda x: float(x.split()[0]) if num_ and x.split() else x.lower(), reverse=rev_)
            except: lines_.sort(reverse=rev_)
            if uniq_:
                seen = set(); lines_ = [l for l in lines_ if l not in seen and not seen.add(l)]
            result = "\n".join(lines_); op(result); return result

        if cmd == "uniq":
            content = pipe_in or ""
            cnt_ = "-c" in args
            prev = None; cnt = 0; result = []
            for ln in content.splitlines():
                if ln == prev: cnt += 1
                else:
                    if prev is not None: result.append(f"{cnt:>7} {prev}" if cnt_ else prev)
                    prev = ln; cnt = 1
            if prev is not None: result.append(f"{cnt:>7} {prev}" if cnt_ else prev)
            out = "\n".join(result); op(out); return out

        if cmd == "cut":
            content = pipe_in or ""; delim = "\t"; fields = []
            i = 0
            while i < len(args):
                if args[i]=="-d" and i+1<len(args): delim=args[i+1]; i+=2
                elif args[i]=="-f" and i+1<len(args):
                    for f in args[i+1].split(","):
                        try: fields.append(int(f)-1)
                        except: pass
                    i+=2
                else: i+=1
            result = []
            for line in content.splitlines():
                ps = line.split(delim)
                result.append(delim.join(ps[f] for f in fields if f<len(ps)) if fields else line)
            out="\n".join(result); op(out); return out

        if cmd == "tr":
            content = pipe_in or ""; nf = [a for a in args if not a.startswith("-")]
            if "-d" in args and nf: out=content.translate(str.maketrans("","",nf[0])); op(out); return out
            if len(nf)>=2:
                src_,dst_ = nf[0],nf[1]; table=str.maketrans(src_[:len(dst_)],dst_[:len(src_)])
                out=content.translate(table); op(out); return out
            op(content); return content

        if cmd == "wc":
            content = pipe_in or (st.read(st.resolve([a for a in args if not a.startswith("-")][-1])) if [a for a in args if not a.startswith("-")] else "")
            if not content: content=""
            l_=len(content.splitlines()); w_=len(content.split()); c_=len(content)
            if "-l" in args: op(str(l_)); return str(l_)
            if "-w" in args: op(str(w_)); return str(w_)
            if "-c" in args: op(str(c_)); return str(c_)
            out=f"{l_} {w_} {c_}"; op(out); return out

        if cmd == "diff":
            ps = [a for a in args if not a.startswith("-")]
            if len(ps)<2: op(r("diff: missing operand")); return None
            c1=st.read(st.resolve(ps[0])).splitlines(); c2=st.read(st.resolve(ps[1])).splitlines()
            op(f"--- {ps[0]}"); op(f"+++ {ps[1]}"); diffs=0
            for i,(a,b) in enumerate(zip(c1,c2)):
                if a!=b: op(d(f"@@ line {i+1} @@")); op(r(f"- {a}")); op(g(f"+ {b}")); diffs+=1
            for ln in c1[len(c2):]: op(r(f"- {ln}")); diffs+=1
            for ln in c2[len(c1):]: op(g(f"+ {ln}")); diffs+=1
            if not diffs: op(d("Files are identical"))
            return None

        if cmd == "tee":
            content = pipe_in or ""; app = "-a" in args
            for p in [a for a in args if not a.startswith("-")]: st.write(st.resolve(p), content, append=app)
            op(content); return content

        if cmd == "printf":
            fmt = (args[0] if args else "").replace("\\n","\n").replace("\\t","\t")
            try: result = fmt % tuple(args[1:]) if len(args)>1 else fmt
            except: result = fmt
            op(result); return result

        # ── search ────────────────────────────────────────────────────────────

        if cmd == "find":
            non_ = [a for a in args if not a.startswith("-")]
            root = st.resolve(non_[0]) if non_ else st.cwd
            name_p=None; iname_p=None; ftype_=None; maxd=99
            i=0
            while i<len(args):
                if args[i]=="-name" and i+1<len(args): name_p=args[i+1]; i+=2
                elif args[i]=="-iname" and i+1<len(args): iname_p=args[i+1]; i+=2
                elif args[i]=="-type" and i+1<len(args): ftype_=args[i+1]; i+=2
                elif args[i]=="-maxdepth" and i+1<len(args):
                    try: maxd=int(args[i+1])
                    except: pass
                    i+=2
                else: i+=1
            results=[]
            for p in st.fs:
                if not p.startswith(root): continue
                if p[len(root):].count("/") > maxd: continue
                name=p.rsplit("/",1)[-1]
                if ftype_=="f" and st.is_dir(p): continue
                if ftype_=="d" and not st.is_dir(p): continue
                if name_p and not fnmatch.fnmatch(name,name_p): continue
                if iname_p and not fnmatch.fnmatch(name.lower(),iname_p.lower()): continue
                results.append(p)
            for rr in sorted(results): op(rr)
            return "\n".join(sorted(results))

        if cmd in ("which","whereis","type"):
            for a in args:
                if st.exists(f"/usr/bin/{a}"): op(f"/usr/bin/{a}")
                elif st.exists(f"/usr/local/bin/{a}"): op(f"/usr/local/bin/{a}")
                elif a in ["ls","cd","pwd","echo","cat","grep","find","sort","wc","cp","mv","rm",
                           "mkdir","chmod","stat","df","du","ps","kill","uname","date","curl","wget",
                           "apt","dpkg","python3","pip3","git","vim","nano","tar","gzip","bash"]:
                    op(f"/usr/bin/{a}")
                else: op(r(f"{cmd}: {a}: not found"))
            return None

        if cmd == "locate":
            q = args[0].lower() if args else ""
            for p in sorted(st.fs): 
                if q in p.lower(): op(p)
            return None

        # ── process ───────────────────────────────────────────────────────────

        if cmd == "ps":
            op(f"{'USER':<8} {'PID':>5} {'%CPU':>5} {'%MEM':>5} {'STAT':<6} COMMAND")
            op(d("─"*60))
            procs = [("root",1,0.0,0.1,"Ss","/sbin/init"),("root",2,0.0,0.0,"S","[kthreadd]"),
                     ("root",388,0.0,0.1,"Ss","/lib/systemd/systemd-journald"),
                     ("root",892,0.0,0.1,"Ss","/usr/sbin/sshd -D"),
                     ("root",901,0.0,0.0,"Ss","/usr/sbin/cron -f"),
                     ("root",1024,0.0,0.1,"S","bash"),
                     ("root",1337,0.1,0.1,"R+","fluxvm")]
            for usr,pid,cpu,mem,stat,cmd_ in procs:
                op(f"{usr:<8} {pid:>5} {cpu:>5.1f} {mem:>5.1f} {(g if 'R' in stat else d)(stat):<13} {d(cmd_)}")
            return None

        if cmd == "top":
            k = st.kernel
            op(c(f"top - {datetime.datetime.now().strftime('%H:%M:%S')} up {self._uptime()}"))
            op(d(f"Tasks: 7 total,  1 running,  6 sleeping"))
            op(d(f"%Cpu(s): {k.cpu.usage:.1f} us,  0.3 sy,  {100-k.cpu.usage:.1f} id"))
            op(d(f"MiB Mem: 64.0 total, 56.0 free, 8.0 used")); op()
            self._cmd("ps", [], None, op)
            op(d("  (non-interactive — use ps for process list)"))
            return None

        if cmd in ("kill","killall"):
            if not args: op(r(f"{cmd}: missing argument")); return None
            op(g(f"Signal sent to process. (FluxVM simulation)")); return None

        if cmd == "jobs": op(d("  (no background jobs)")); return None

        if cmd == "watch":
            if args: op(d(f"Every 2.0s: {' '.join(args)}")); op(); self._cmd(args[0],args[1:],None,op)
            return None

        if cmd in ("nohup","nice"):
            if args: self._cmd(args[0],args[1:],None,op)
            return None

        # ── system info ───────────────────────────────────────────────────────

        if cmd == "uname":
            if "-a" in args: op("Linux fluxvm 6.8.0-47-generic #47-Ubuntu SMP PREEMPT_DYNAMIC x86_64 GNU/Linux")
            elif "-r" in args: op("6.8.0-47-generic")
            elif "-s" in args: op("Linux")
            elif "-m" in args: op("x86_64")
            elif "-n" in args: op("fluxvm")
            else: op("Linux")
            return None

        if cmd == "hostname":
            if args: st.fs["/etc/hostname"]["content"]=args[0]+"\n"; st.env["HOSTNAME"]=args[0]; st._save()
            else: op(st.env.get("HOSTNAME","fluxvm"))
            return None

        if cmd == "uptime":
            k = st.kernel; op(f" {datetime.datetime.now().strftime('%H:%M:%S')} up {self._uptime()},  1 user,  load average: {k.cpu.usage/100:.2f}")
            return None

        if cmd == "date":
            if args and args[0].startswith("+"): op(datetime.datetime.now().strftime(args[0][1:]))
            else: op(datetime.datetime.now().strftime("%a %b %d %H:%M:%S %Z %Y"))
            return None

        if cmd == "cal":
            import calendar; now=datetime.datetime.now(); op(calendar.month(now.year,now.month)); return None

        if cmd == "whoami": op(st.user); return st.user

        if cmd == "id":
            uid = 0 if st.user=="root" else 1000
            op(f"uid={uid}({st.user}) gid={uid}({st.user}) groups={uid}({st.user})")
            return None

        if cmd in ("env","printenv"):
            if args:
                for a in args: op(st.env.get(a,""))
            else:
                for k,v in sorted(st.env.items()): op(f"{k}={v}")
            return None

        if cmd == "lscpu":
            k = st.kernel
            op(f"Architecture:   x86_64\nCPU(s):         {k.cpu.cores}")
            op(f"Model name:     FluxCPU v1 @ {k.cpu.clock_speed_mhz}GHz")
            op(f"CPU MHz:        {k.cpu.clock_speed_mhz*1000:.3f}")
            op(f"L3 cache:       8 MiB"); return None

        if cmd == "lsblk":
            op("NAME   MAJ:MIN RM   SIZE RO TYPE MOUNTPOINTS")
            op("sda      8:0    0    20G  0 disk")
            op("├─sda1   8:1    0    19G  0 part /")
            op("└─sda2   8:2    0     1G  0 part [SWAP]"); return None

        if cmd in ("lsusb","lspci"):
            op("Bus 001 Device 001: ID 1d6b:0002 Linux Foundation 2.0 root hub") if cmd=="lsusb" else op("00:00.0 Host bridge: Intel Corporation FluxBridge")
            return None

        if cmd == "dmesg":
            op(d("[    0.000000] Initializing cgroup subsys cpuset"))
            op(d("[    0.000000] Linux version 6.8.0-47-generic"))
            op(d("[    1.234567] NET: Registered PF_INET protocol family"))
            op(d("[    2.780033] EXT4-fs (sda1): mounted filesystem")); return None

        if cmd == "journalctl":
            op(d("-- Logs begin at Thu 2024-01-01 00:00:00 UTC --"))
            for ln in st.read("/var/log/syslog").splitlines(): op(d(ln)); return None

        if cmd == "free":
            human_ = "-h" in args; total=65536*1024; used=8192*1024; free_=total-used; cache=16384*1024
            op(f"{'':14} {'total':>8} {'used':>8} {'free':>8} {'buff/cache':>12} {'available':>12}")
            if human_:
                op(f"{'Mem:':14} {self._human(total):>8} {self._human(used):>8} {self._human(free_):>8} {self._human(cache):>12} {self._human(free_+cache):>12}")
                op(f"{'Swap:':14} {'2.0G':>8} {'0B':>8} {'2.0G':>8}")
            else:
                op(f"{'Mem:':14} {total//1024:>8} {used//1024:>8} {free_//1024:>8} {cache//1024:>12} {(free_+cache)//1024:>12}")
            return None

        # ── network ───────────────────────────────────────────────────────────

        if cmd == "ping":
            target = next((a for a in args if not a.startswith("-")), "8.8.8.8")
            cnt = 4
            if "-c" in args:
                try: cnt=int(args[args.index("-c")+1])
                except: pass
            op(f"PING {target}: 56 data bytes")
            for i in range(cnt):
                ms=random.uniform(0.5,12.0); op(f"64 bytes from {target}: icmp_seq={i+1} ttl=64 time={ms:.3f} ms")
                time.sleep(0.15)
            op(f"\n--- {target} ping statistics ---")
            op(f"{cnt} packets transmitted, {cnt} received, 0% packet loss"); return None

        if cmd == "curl":
            url = next((a for a in args if a.startswith("http")), None)
            if not url: op(r("curl: (3) URL missing")); return None
            silent = "-s" in args or "--silent" in args
            head   = "-I" in args or "--head" in args
            out_f  = args[args.index("-o")+1] if "-o" in args else None
            if head:
                op(f"HTTP/2 200\ncontent-type: text/html\nserver: nginx/1.24.0")
                return None
            fake = f"<!-- FluxVM response from {url} -->\n<html><body><h1>FluxVM HTTP Stub</h1></body></html>"
            if not silent: op(fake)
            if out_f: st.write(st.resolve(out_f), fake)
            return fake

        if cmd == "wget":
            url = next((a for a in args if a.startswith("http")), None)
            if not url: op(r("wget: missing URL")); return None
            fname = url.split("/")[-1] or "index.html"
            op(f"--{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}--  {url}")
            op(f"Resolving {url.split('/')[2]}... 203.0.113.1")
            op(f"HTTP request sent, awaiting response... 200 OK")
            op(f"Saving to: '{fname}'")
            content = f"<!-- FluxVM simulated download from {url} -->"
            st.write(st.resolve(fname), content)
            op(f"\n'{fname}' saved [1024/1024]"); return None

        if cmd == "ssh": op(r("ssh: connect to host: Network unreachable")); return None

        if cmd in ("netstat","ss"):
            op(f"{'Proto':<6} {'Local Address':<25} {'Foreign Address':<25} State")
            op(d("─"*65))
            op(f"{'tcp':<6} {'0.0.0.0:22':<25} {'0.0.0.0:*':<25} {g('LISTEN')}")
            op(f"{'tcp6':<6} {':::80':<25} {':::*':<25} {g('LISTEN') if 'nginx' in st.installed or 'apache2' in st.installed else d('(none)')}")
            return None

        if cmd == "ip":
            if not args or args[0] in ("a","addr"):
                op("1: lo: <LOOPBACK,UP>"); op("    inet 127.0.0.1/8 scope host lo")
                op("2: eth0: <BROADCAST,MULTICAST,UP>"); op("    inet 10.0.2.15/24 scope global eth0")
            elif args[0] in ("r","route"):
                op("default via 10.0.2.1 dev eth0"); op("10.0.2.0/24 dev eth0 proto kernel")
            return None

        if cmd == "ifconfig":
            op("eth0: flags=4163<UP,BROADCAST,RUNNING>  mtu 1500")
            op("      inet 10.0.2.15  netmask 255.255.255.0  broadcast 10.0.2.255")
            op("      ether 52:54:00:12:34:56"); return None

        if cmd in ("nslookup","dig","host"):
            target = args[0] if args else "localhost"
            op(f"Server:\t\t1.1.1.1\nAddress:\t1.1.1.1#53\n")
            op(f"Non-authoritative answer:\nName:\t{target}\nAddress: 93.184.216.34"); return None

        if cmd == "traceroute":
            target = args[-1] if args else "8.8.8.8"
            op(f"traceroute to {target}, 30 hops max, 60 byte packets")
            for i,(ip,name) in enumerate([("10.0.2.1","gateway"),("203.0.113.1","isp"),("8.8.8.8",target)],1):
                ms = [random.uniform(1,30) for _ in range(3)]
                op(f" {i}  {name} ({ip})  {'  '.join(f'{m:.3f} ms' for m in ms)}")
                time.sleep(0.1)
            return None

        if cmd == "nmap":
            target = next((a for a in args if not a.startswith("-")), "localhost")
            op(f"Nmap scan report for {target} (127.0.0.1)")
            op(f"PORT   STATE SERVICE"); op(f"22/tcp open  ssh     OpenSSH 9.6p1")
            if "nginx" in st.installed: op(f"80/tcp open  http    nginx 1.24.0")
            if "apache2" in st.installed: op(f"80/tcp open  http    Apache httpd 2.4.58")
            op(f"Nmap done: 1 IP address (1 host up)"); return None

        # ── archive ───────────────────────────────────────────────────────────

        if cmd == "tar":
            flags_ = args[0] if args else ""; rest = args[1:]
            create_=("c" in flags_); extract_=("x" in flags_); list__=("t" in flags_); verb_=("v" in flags_)
            archive = next((a for a in rest if any(a.endswith(e) for e in (".tar",".tar.gz",".tgz",".tar.bz2"))), None)
            files_  = [a for a in rest if a != archive and not a.startswith("-")]
            if create_:
                members = {}
                for f in files_:
                    fp = st.resolve(f)
                    if st.is_file(fp): members[f] = st.read(fp)
                    elif st.is_dir(fp):
                        for p in st.fs:
                            if p.startswith(fp) and st.is_file(p): members[p[len(fp):].lstrip("/")] = st.read(p)
                payload = json.dumps({"format":"FLUXTGZ:1","members":members})
                out = archive or "archive.tar"; st.write(st.resolve(out), payload)
                if verb_:
                    for m in members: op(m)
                op(g(f"tar: {out} created ({len(members)} member(s))"))
            elif extract_:
                if not archive: op(r("tar: must specify archive")); return None
                content = st.read(st.resolve(archive))
                try:
                    data = json.loads(content)
                    for name,body in data.get("members",{}).items():
                        st.write(st.resolve(name), body)
                        if verb_: op(name)
                    op(g(f"tar: extracted {len(data.get('members',{}))} members"))
                except: op(r(f"tar: {archive}: not a valid archive"))
            elif list__:
                content = st.read(st.resolve(archive)) if archive else ""
                try:
                    for name in json.loads(content).get("members",{}): op(name)
                except: op(r(f"tar: not a valid archive"))
            return None

        if cmd in ("gzip","gunzip","zip","unzip","xz"):
            op(g(f"{cmd}: operation simulated")); return None

        # ── package management ────────────────────────────────────────────────

        if cmd in ("apt","apt-get"): return self._apt(args, op)
        if cmd == "dpkg":            return self._dpkg(args, op)
        if cmd in ("pip","pip3"):    return self._pip(args, op)

        # ── shell misc ────────────────────────────────────────────────────────

        if cmd == "sudo":
            if args: return self._cmd(args[0],args[1:],pipe_in,op)
            return None

        if cmd == "su":
            u = args[0] if args else "root"
            st.user=u; st.env["USER"]=u; st.env["HOME"]=f"/root" if u=="root" else f"/home/{u}"
            op(d(f"Switched to {u}")); return None

        if cmd in ("vim","vi","nano","emacs"):
            if not args: op(r(f"{cmd}: missing filename")); return None
            fp = st.resolve(args[0])
            op(c(f"[{cmd.upper()}]  {fp}  (empty line saves and exits, Ctrl+C cancels)"))
            lines_ = []
            try:
                while True:
                    ln = input(d("> "))
                    if ln == "": break
                    lines_.append(ln)
            except (EOFError, KeyboardInterrupt): op(d("\nCancelled.")); return None
            st.write(fp, "\n".join(lines_)+"\n")
            op(g(f"[{cmd}] {fp} written ({len(lines_)} lines)")); return None

        if cmd == "man":
            topic = args[0] if args else "man"
            op(c(f"MAN({topic.upper()})"))
            op(f"NAME\n    {topic} — available in FluxVM Ubuntu 24.04 LTS")
            op(f"DESCRIPTION\n    For full docs: https://manpages.ubuntu.com/manpages/noble/en/man1/{topic}.1.html")
            try: input(d("\n(press ENTER)"))
            except: pass
            return None

        if cmd == "sleep":
            try: time.sleep(min(float(args[0]) if args else 1, 5))
            except: pass
            return None

        if cmd == "read":
            var = args[0] if args else "REPLY"
            try: st.env[var] = input()
            except: st.env[var] = ""
            return None

        if cmd == "xargs":
            content = pipe_in or ""
            if args:
                for item in content.split(): self._cmd(args[0],args[1:]+[item],None,op)
            return None

        if cmd == "seq":
            try:
                if len(args)==1: start_,step_,end_ = 1,1,int(args[0])
                elif len(args)==2: start_,step_,end_ = int(args[0]),1,int(args[1])
                else: start_,step_,end_ = int(args[0]),int(args[1]),int(args[2])
                result = "\n".join(str(i) for i in range(start_,end_+1,step_))
                op(result); return result
            except: return None

        if cmd == "bc":
            if pipe_in:
                try: result=str(eval(pipe_in.strip())); op(result); return result
                except: op(r("bc: invalid expression"))
            return None

        if cmd == "neofetch": self._neofetch(op); return None

        if cmd == "htop":
            op(d("htop is non-interactive in FluxVM — showing ps output:"))
            self._cmd("ps",[],None,op); return None

        if cmd == "strace":
            prog=args[0] if args else "?"
            op(d(f'execve("/usr/bin/{prog}", ["{prog}"], envp) = 0'))
            op(d("brk(NULL) = 0x55e000")); op(d("+++ exited with 0 +++"))
            return None

        if cmd == "lsof":
            op(f"{'COMMAND':<12} {'PID':>6} {'USER':<8} TYPE  NAME")
            for name,pid in [("systemd",1),("sshd",892),("bash",1024),("fluxvm",1337)]:
                op(f"{name:<12} {pid:>6} {st.user:<8} DIR   {st.cwd}")
            return None

        if cmd == "crontab":
            if "-l" in args:
                op(d("# no crontab for root — use 'write /var/spool/cron/crontabs/root ...'"))
            return None

        if cmd in ("true","false"): return None

        if cmd == "yes": op(d("(yes: suppressed in FluxVM)")); return None

        if cmd == "env" and not args:
            for k,v in sorted(st.env.items()): op(f"{k}={v}")
            return None

        op(r(f"bash: {cmd}: command not found")); return None

    # ── apt implementation ────────────────────────────────────────────────────

    def _apt(self, args, op):
        if not args: op(r("apt: missing command")); return None
        sub = args[0]; rest = args[1:]

        if sub == "update":
            op(g("Hit:1 http://archive.ubuntu.com/ubuntu noble InRelease"))
            op(g("Hit:2 http://archive.ubuntu.com/ubuntu noble-updates InRelease"))
            op(g("Hit:3 http://security.ubuntu.com/ubuntu noble-security InRelease"))
            time.sleep(0.3)
            op(g("Reading package lists... Done"))
            op(d("Building dependency tree... Done"))
            op(g("All packages are up to date."))
            self._apt_updated = True
            return None

        if sub in ("upgrade","full-upgrade","dist-upgrade"):
            op(g("Reading package lists... Done\nBuilding dependency tree... Done"))
            upgradable = [(n,APT_REPO[n]["ver"]) for n in self.state.installed if n in APT_REPO]
            if not upgradable: op(g("0 upgraded, 0 newly installed, 0 to remove.")); return None
            op(f"The following packages will be upgraded:\n  {' '.join(n for n,_ in upgradable)}")
            op(f"{len(upgradable)} upgraded.")
            yes = "-y" in rest
            if not yes:
                try: yn=input(y("Do you want to continue? [Y/n] ")).strip().lower()
                except: yn="y"
                if yn in ("n","no"): op(d("Abort.")); return None
            for n,ver in upgradable:
                op(d(f"  Setting up {n} ({ver}) ...")); self.state.installed[n]["ver"]=ver
            self.state._save(); op(g("Done.")); return None

        if sub in ("install",):
            pkgs    = [a for a in rest if not a.startswith("-")]
            yes     = "-y" in rest or "--yes" in rest
            if not pkgs: op(r("apt: install: no package specified")); return None
            to_install = []; unknown = []
            for pkg in pkgs:
                if pkg in APT_REPO:
                    if pkg not in to_install: to_install.append(pkg)
                    for dep in APT_REPO[pkg].get("deps",[]):
                        dep_base = dep.split()[0]
                        if dep_base in APT_REPO and dep_base not in to_install:
                            to_install.append(dep_base)
                else: unknown.append(pkg)
            if unknown:
                op(r(f"E: Unable to locate package(s): {' '.join(unknown)}"))
                if not to_install: return None
            new_  = [p for p in to_install if p not in self.state.installed]
            already = [p for p in to_install if p in self.state.installed]
            for p in already: op(y(f"{p} is already the newest version ({APT_REPO[p]['ver']})."))
            if not new_: return None
            op(f"The following NEW packages will be installed:\n  {' '.join(new_)}")
            total_sz = sum(self._parse_size(APT_REPO.get(p,{}).get("size","0")) for p in new_)
            op(f"{len(new_)} newly installed. Need to get {self._human(total_sz)} of archives.")
            if not yes:
                try: yn=input(y("Do you want to continue? [Y/n] ")).strip().lower()
                except: yn="y"
                if yn in ("n","no"): op(d("Abort.")); return None
            for pkg in new_:
                ver=APT_REPO[pkg]["ver"]; sz=APT_REPO[pkg].get("size","0 kB")
                op(d(f"Get:1 http://archive.ubuntu.com/ubuntu noble/main amd64 {pkg} {ver} [{sz}]"))
            time.sleep(0.3)
            op(g(f"Fetched {self._human(total_sz)} in 0.{random.randint(1,9)}s"))
            op("Selecting previously unselected package(s).")
            for pkg in new_:
                ver=APT_REPO[pkg]["ver"]
                op(d(f"Preparing to unpack .../archives/{pkg}_{ver}_amd64.deb ..."))
                op(d(f"Unpacking {pkg} ({ver}) ..."))
            for pkg in new_:
                ver=APT_REPO[pkg]["ver"]
                op(d(f"Setting up {pkg} ({ver}) ..."))
                self.state.mark_installed(pkg,ver)
                self._apt_log(f"Install: {pkg} ({ver})")
            op(d("Processing triggers for man-db (2.12.0-4build2) ..."))
            op(g("Done.")); return None

        if sub in ("remove","purge"):
            pkgs=[a for a in rest if not a.startswith("-")]; yes="-y" in rest
            for pkg in pkgs:
                if pkg not in self.state.installed: op(y(f"Package '{pkg}' is not installed, so not removed.")); continue
                if not yes:
                    try: yn=input(y(f"Remove {pkg}? [Y/n] ")).strip().lower()
                    except: yn="y"
                    if yn in ("n","no"): continue
                op(d(f"Removing {pkg} ..."))
                self.state.mark_removed(pkg)
                self._apt_log(f"Remove: {pkg}")
                op(g(f"Done."))
            return None

        if sub == "autoremove":
            op(g("0 to remove. (FluxVM: autoremove simulation)")); return None

        if sub in ("search","show","info"):
            query = rest[0].lower() if rest else ""
            if sub == "search":
                op(d(f"Sorting...  Done\nFull text search...  Done"))
                found = [(n,d_) for n,d_ in APT_REPO.items() if query in n or query in d_["desc"].lower()]
                for name,info in found: op(f"{g(name)}/{d('noble')} {info['ver']}\n  {d(info['desc'])}")
                if not found: op(d(f"No results for '{query}'"))
            elif sub in ("show","info"):
                pkg = rest[0] if rest else ""; info = APT_REPO.get(pkg)
                if not info: op(r(f"N: Unable to locate package {pkg}")); return None
                installed = pkg in self.state.installed
                op(f"Package: {g(pkg)}")
                op(f"Version: {info['ver']}")
                op(f"Size:    {info['size']}")
                op(f"Status:  {'installed' if installed else 'not installed'}")
                op(f"Depends: {', '.join(info.get('deps',[])) or 'none'}")
                op(f"Desc:    {info['desc']}")
            return None

        if sub == "list":
            installed_only = "--installed" in rest; upgradable_ = "--upgradable" in rest
            for n,info in APT_REPO.items():
                inst = n in self.state.installed
                if installed_only and not inst: continue
                tag = g("[installed]") if inst else d("[available]")
                op(f"{n}/{d('noble')} {info['ver']} amd64  {tag}")
            return None

        op(r(f"apt: invalid operation '{sub}'")); return None

    def _apt_log(self, entry):
        existing = self.state.read("/var/log/apt/history.log")
        self.state.write("/var/log/apt/history.log",
            existing + f"\nDate: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{entry}\n")

    def _dpkg(self, args, op):
        if not args: op(r("dpkg: error: need an action option")); return None
        sub = args[0]; rest = args[1:]
        if sub == "-l" or sub == "--list":
            query = rest[0].lower() if rest else ""
            op(f"{'Desired=U/I/R/P/H'}")
            op(f"{'||/ Name':<30} {'Version':<20} Architecture")
            op("─"*70)
            for n,info in APT_REPO.items():
                if query and query not in n: continue
                inst = n in self.state.installed
                ver  = self.state.installed[n]["ver"] if inst else info["ver"]
                status = "ii" if inst else "un"
                op(f"{(g if inst else d)(status)  } {n:<28} {ver:<20} amd64")
        elif sub in ("-s","--status"):
            pkg = rest[0] if rest else ""
            info = APT_REPO.get(pkg)
            if not info: op(r(f"dpkg-query: package '{pkg}' is not installed")); return None
            inst = pkg in self.state.installed
            op(f"Package: {pkg}\nStatus: {'install ok installed' if inst else 'unknown ok not-installed'}")
            op(f"Version: {self.state.installed[pkg]['ver'] if inst else info['ver']}")
            op(f"Description: {info['desc']}")
        elif sub in ("-L","--listfiles"):
            pkg = rest[0] if rest else ""
            if pkg not in self.state.installed: op(r(f"dpkg-query: package '{pkg}' is not installed")); return None
            op(f"/usr/bin/{pkg}\n/usr/share/doc/{pkg}")
        elif sub in ("-i","--install"):
            deb = rest[0] if rest else ""
            op(r(f"dpkg: error: cannot access archive '{deb}': No such file or directory"))
            op(d("  (in FluxVM, use 'apt install <package>' instead)"))
        else:
            op(r(f"dpkg: error: unknown option '{sub}'"))
        return None

    def _pip(self, args, op):
        if not args: op(r("pip: no command given")); return None
        sub = args[0]; rest = args[1:]
        PIP_PKGS = {
            "requests":{"ver":"2.31.0","desc":"Python HTTP for Humans"},
            "flask":{"ver":"3.0.2","desc":"A simple framework for building complex web applications"},
            "django":{"ver":"5.0.3","desc":"A high-level Python web framework"},
            "numpy":{"ver":"1.26.4","desc":"Fundamental package for array computing with Python"},
            "pandas":{"ver":"2.2.1","desc":"Powerful data structures for data analysis"},
            "matplotlib":{"ver":"3.8.3","desc":"Python plotting package"},
            "scipy":{"ver":"1.12.0","desc":"Fundamental algorithms for scientific computing"},
            "scikit-learn":{"ver":"1.4.1","desc":"Machine learning in Python"},
            "tensorflow":{"ver":"2.16.1","desc":"TensorFlow is an open source machine learning framework"},
            "torch":{"ver":"2.2.1","desc":"PyTorch: tensors and dynamic neural networks in Python"},
            "fastapi":{"ver":"0.110.0","desc":"FastAPI framework, high performance"},
            "sqlalchemy":{"ver":"2.0.28","desc":"Database Abstraction Library"},
            "pydantic":{"ver":"2.6.4","desc":"Data validation using Python type hints"},
            "pytest":{"ver":"8.1.1","desc":"pytest: simple powerful testing with Python"},
            "black":{"ver":"24.3.0","desc":"The uncompromising code formatter"},
            "httpx":{"ver":"0.27.0","desc":"The next generation HTTP client"},
            "uvicorn":{"ver":"0.29.0","desc":"The lightning-fast ASGI server"},
            "celery":{"ver":"5.3.6","desc":"Distributed task queue"},
            "redis":{"ver":"5.0.3","desc":"Python client for Redis database"},
            "boto3":{"ver":"1.34.70","desc":"AWS SDK for Python"},
            "paramiko":{"ver":"3.4.0","desc":"SSH2 protocol library"},
            "cryptography":{"ver":"42.0.5","desc":"Cryptographic recipes and primitives"},
            "pillow":{"ver":"10.2.0","desc":"Python Imaging Library"},
            "aiohttp":{"ver":"3.9.3","desc":"Async HTTP client/server framework"},
            "click":{"ver":"8.1.7","desc":"Composable command line interface toolkit"},
            "rich":{"ver":"13.7.1","desc":"Render rich text, tables, progress bars, markdown"},
            "typer":{"ver":"0.12.2","desc":"Build great CLIs with Python, using type hints"},
            "pyyaml":{"ver":"6.0.1","desc":"YAML parser and emitter for Python"},
        }
        pip_key = "pip_installed"
        if pip_key not in self.state.installed:
            self.state.installed[pip_key] = {"ver":"__meta__","pkgs":{}}
        pip_installed = self.state.installed[pip_key].get("pkgs",{})

        if sub == "install":
            pkgs_ = [a for a in rest if not a.startswith("-")]
            quiet = "-q" in rest
            for pkg in pkgs_:
                # Handle pkg==version or pkg>=version
                pkg_base = re.split(r'[=><]', pkg)[0]
                info = PIP_PKGS.get(pkg_base)
                ver_ = info["ver"] if info else "0.1.0"
                if not quiet: op(d(f"Collecting {pkg}"))
                if not quiet: op(d(f"  Downloading {pkg_base}-{ver_}-py3-none-any.whl"))
                if not quiet: op(g(f"Successfully installed {pkg_base}-{ver_}"))
                pip_installed[pkg_base] = ver_
            self.state.installed[pip_key]["pkgs"] = pip_installed
            self.state._save()

        elif sub in ("list","freeze"):
            for name,ver_ in sorted(pip_installed.items()):
                if sub == "freeze": op(f"{name}=={ver_}")
                else: op(f"{g(name)} {d(ver_)}")

        elif sub in ("uninstall","remove"):
            for pkg in rest:
                if pkg in pip_installed:
                    del pip_installed[pkg]
                    op(g(f"Successfully uninstalled {pkg}"))
                else: op(y(f"WARNING: Skipping {pkg} as it is not installed."))
            self.state.installed[pip_key]["pkgs"] = pip_installed; self.state._save()

        elif sub == "show":
            for pkg in rest:
                info = PIP_PKGS.get(pkg)
                ver_ = pip_installed.get(pkg,"not installed")
                op(f"Name: {pkg}\nVersion: {ver_}\nDescription: {info['desc'] if info else 'unknown'}")

        elif sub == "search":
            q = rest[0].lower() if rest else ""
            for name,info in PIP_PKGS.items():
                if q in name or q in info["desc"].lower(): op(f"{g(name)} ({info['ver']}) - {d(info['desc'])}")

        else: op(r(f"pip: error: unknown command '{sub}'"))
        return None

    # ── neofetch ──────────────────────────────────────────────────────────────

    def _neofetch(self, op):
        k   = self.state.kernel
        logo = [
            f"  {G}           ..-::::::-.{R}",
            f"  {G}       .-::::::::::::::-.{R}",
            f"  {G}     .::::::::::::::::::::.{R}",
            f"  {G}    .::/            \\:::::::.{R}",
            f"  {G}   .:::  {Y}████████{G}  :::::::::.{R}",
            f"  {G}  .::::: {Y}████████{G} ::::::::::::{R}",
            f"  {G}  .-:::{Y}██████████{G}:::::::::::-.{R}",
            f"  {G} .:::::{Y}████  ████{G}:::::::::::::. {R}",
            f"  {G}  '::::{Y}████  ████{G}::::::::::::'  {R}",
            f"  {G}   '-:::{Y}██████████{G}::::::::::-'  {R}",
            f"  {G}     '-:::::::::::::::::::::::'  {R}",
            f"  {G}        '-:::::::::::::::::'    {R}",
            f"  {G}            ''-::::-''          {R}",
        ]
        installed_count = len([k_ for k_ in self.state.installed if k_ != "pip_installed"])
        info = [
            f"{g(self.state.user+'@fluxvm')}",
            d("─"*22),
            f"{c('OS')}:       Ubuntu 24.04 LTS Noble Numbat",
            f"{c('Host')}:     FluxVM (Flux OS Hypervisor)",
            f"{c('Kernel')}:   Linux 6.8.0-47-generic",
            f"{c('Uptime')}:   {self._uptime()}",
            f"{c('Packages')}: {installed_count} (dpkg)",
            f"{c('Shell')}:    bash 5.2.21",
            f"{c('Terminal')}: FluxVM",
            f"{c('CPU')}:      FluxCPU v1 @ {k.cpu.clock_speed_mhz}GHz ({k.cpu.cores}) @ {k.cpu.usage:.1f}%",
            f"{c('Memory')}:   8192MiB / 65536MiB",
            "",
            "  " + "".join(f"\033[4{i}m  {R}" for i in range(8)),
        ]
        for i in range(max(len(logo),len(info))):
            left  = logo[i]  if i < len(logo)  else " "*34
            right = info[i]  if i < len(info)  else ""
            op(f"{left}  {right}")

    # ── helpers ───────────────────────────────────────────────────────────────

    def _uptime(self):
        s = int(time.time() - self.state.boot_time)
        h,rem=divmod(s,3600); m,s=divmod(rem,60)
        return f"{h}h {m}m {s}s"

    def _human(self, n):
        for unit in ("B","K","M","G","T"):
            if n < 1024: return f"{n:.1f}{unit}"
            n /= 1024
        return f"{n:.1f}P"

    def _parse_size(self, s):
        try:
            parts = s.strip().split()
            val = float(parts[0].replace(",",""))
            unit = parts[1].lower() if len(parts)>1 else "b"
            mult = {"b":1,"kb":1024,"mb":1024**2,"gb":1024**3}.get(unit,1)
            return int(val*mult)
        except: return 0

    def _mode_str(self, mode):
        try:
            m = int(str(mode), 8)
            s = ""
            for shift in (6,3,0):
                b = (m>>shift)&7
                s += ("r" if b&4 else "-") + ("w" if b&2 else "-") + ("x" if b&1 else "-")
            return s
        except: return "rw-r--r--"


# ─────────────────────────────────────────────────────────────────────────────
# Entry point — called by Flux OS package system
# ─────────────────────────────────────────────────────────────────────────────

def run(kernel):
    state = VMState(kernel)
    shell = FluxVMShell(state)

    # Boot banner
    print()
    print(f"{G}╔══════════════════════════════════════════════════════╗{R}")
    print(f"{G}║  FluxVM — Ubuntu 24.04 LTS Noble Numbat              ║{R}")
    print(f"{G}║  Linux 6.8.0-47-generic  |  x86_64                   ║{R}")
    print(f"{G}║  Type 'help' for commands  |  'exit' to return Flux   ║{R}")
    print(f"{G}╚══════════════════════════════════════════════════════╝{R}")
    print()
    print(f"{D}Last login: {datetime.datetime.now().strftime('%a %b %d %H:%M:%S %Y')} from 10.0.2.1{R}")
    print()

    shell.run()

    print()
    print(f"{D}[FluxVM session ended — returned to Flux OS]{R}")
    print()