"""
notes.py — simple text editor backed by FluxFS
fpt install notes
"""

MANIFEST = {
    "name":        "notes",
    "version":     "1.0.0",
    "description": "Line-based text editor — saves notes to FluxFS",
    "commands":    ["notes"],
    "author":      "FluxTeam",
}

_ANSI_R  = "\033[0m"
_ANSI_G  = "\033[92m"
_ANSI_C  = "\033[96m"
_ANSI_Y  = "\033[93m"
_ANSI_D  = "\033[2m"
_ANSI_RE = "\033[91m"
_ANSI_W  = "\033[97m"

def _g(t): return f"{_ANSI_G}{t}{_ANSI_R}"
def _c(t): return f"{_ANSI_C}{t}{_ANSI_R}"
def _y(t): return f"{_ANSI_Y}{t}{_ANSI_R}"
def _d(t): return f"{_ANSI_D}{t}{_ANSI_R}"
def _r(t): return f"{_ANSI_RE}{t}{_ANSI_R}"
def _w(t): return f"{_ANSI_W}{t}{_ANSI_R}"

NOTES_DIR = "/home/notes"


def _ensure_dir(kernel):
    ok, _ = kernel.fs.stat("MainPartition", NOTES_DIR)
    if not ok:
        kernel.fs.mkdir("MainPartition", NOTES_DIR)


def _list_notes(kernel):
    ok, entries = kernel.fs.listdir("MainPartition", NOTES_DIR)
    if not ok:
        return []
    return [name for name, inode in entries if not inode.is_dir()]


def _load_note(kernel, name):
    path = f"{NOTES_DIR}/{name}"
    ok, content = kernel.fs.read_file("MainPartition", path)
    return content if ok else ""


def _save_note(kernel, name, content):
    path = f"{NOTES_DIR}/{name}"
    kernel.fs.create_file("MainPartition", path, content=content)


def _delete_note(kernel, name):
    path = f"{NOTES_DIR}/{name}"
    kernel.fs.delete("MainPartition", path, recursive=False)


def _edit_note(kernel, name):
    """Line-based editor for a single note."""
    lines = _load_note(kernel, name).splitlines()
    dirty = False

    print()
    print(_c(f"  ── notes: {name} ──────────────────────────────"))
    print(_d("  Commands: :w save  :q quit  :wq save+quit"))
    print(_d("            :d <n> delete line  :i <n> insert before line"))
    print(_d("            :p print  :cls clear all  :h help"))
    print(_d("  Anything else is appended as a new line."))
    print(_d("  ─" * 26))

    def _print_buf():
        if not lines:
            print(_d("  (empty)"))
            return
        for i, l in enumerate(lines, 1):
            print(f"  {_d(str(i).rjust(3))}  {l}")

    _print_buf()
    print()

    while True:
        try:
            raw = input(_y(f"  [{name}]> ")).rstrip("\n")
        except (EOFError, KeyboardInterrupt):
            print()
            if dirty:
                try:
                    confirm = input(_y("  Unsaved changes — save before exit? [y/N] ")).strip().lower()
                except (EOFError, KeyboardInterrupt):
                    confirm = "n"
                if confirm == "y":
                    _save_note(kernel, name, "\n".join(lines))
                    print(_g("  saved."))
            break

        # ── commands ──────────────────────────────────────────────────────────
        if raw == ":w":
            _save_note(kernel, name, "\n".join(lines))
            dirty = False
            print(_g("  saved."))

        elif raw in (":q", ":quit"):
            if dirty:
                try:
                    confirm = input(_y("  Unsaved changes — save? [y/N] ")).strip().lower()
                except (EOFError, KeyboardInterrupt):
                    confirm = "n"
                if confirm == "y":
                    _save_note(kernel, name, "\n".join(lines))
                    print(_g("  saved."))
            break

        elif raw in (":wq", ":x"):
            _save_note(kernel, name, "\n".join(lines))
            dirty = False
            print(_g("  saved."))
            break

        elif raw == ":p":
            _print_buf()

        elif raw == ":cls":
            confirm = input(_y("  Clear all lines? [y/N] ")).strip().lower()
            if confirm == "y":
                lines.clear()
                dirty = True
                print(_d("  buffer cleared."))

        elif raw.startswith(":d "):
            try:
                n = int(raw[3:].strip()) - 1
                removed = lines.pop(n)
                dirty = True
                print(_d(f"  deleted line {n+1}: {removed}"))
            except (ValueError, IndexError):
                print(_r("  :d <line number>"))

        elif raw.startswith(":i "):
            parts = raw[3:].split(" ", 1)
            try:
                n = int(parts[0]) - 1
                text = parts[1] if len(parts) > 1 else ""
                lines.insert(n, text)
                dirty = True
                print(_d(f"  inserted at line {n+1}"))
            except (ValueError, IndexError):
                print(_r("  :i <line number> <text>"))

        elif raw == ":h":
            print(_d("  :w        save"))
            print(_d("  :q        quit (prompts if unsaved)"))
            print(_d("  :wq / :x  save and quit"))
            print(_d("  :p        print buffer with line numbers"))
            print(_d("  :cls      clear entire buffer"))
            print(_d("  :d <n>    delete line n"))
            print(_d("  :i <n> t  insert text t before line n"))

        elif raw.startswith(":"):
            print(_r(f"  unknown command '{raw}'"))

        else:
            # append line
            lines.append(raw)
            dirty = True

    print()


def run(kernel):
    _ensure_dir(kernel)

    print()
    print(_c("  FluxNotes 1.0"))
    print(_d("  ─" * 28))

    while True:
        notes = _list_notes(kernel)

        if notes:
            print(_c("  Saved notes:"))
            for i, n in enumerate(notes, 1):
                content = _load_note(kernel, n)
                preview = content[:40].replace("\n", " ")
                print(f"  {_g(str(i).rjust(2))}  {_w(n):<22} {_d(preview)}")
        else:
            print(_d("  (no notes yet)"))

        print()
        print(_d("  open <name>   new <name>   delete <name>   exit"))
        print()

        try:
            cmd = input(_y("  notes> ")).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break

        if not cmd:
            continue

        parts = cmd.split(None, 1)
        sub   = parts[0].lower()
        arg   = parts[1].strip() if len(parts) > 1 else ""

        if sub in ("exit", "quit", "q"):
            break

        elif sub in ("open", "edit", "new"):
            if not arg:
                print(_r("  usage: open <name>"))
                continue
            # sanitise name
            safe = "".join(c for c in arg if c.isalnum() or c in "-_.")
            if not safe:
                print(_r("  invalid note name"))
                continue
            if not safe.endswith(".txt"):
                safe += ".txt"
            _edit_note(kernel, safe)

        elif sub == "delete":
            if not arg:
                print(_r("  usage: delete <name>"))
                continue
            if not arg.endswith(".txt"):
                arg += ".txt"
            if arg not in notes:
                print(_r(f"  note '{arg}' not found"))
                continue
            confirm = input(_y(f"  Delete '{arg}'? [y/N] ")).strip().lower()
            if confirm == "y":
                _delete_note(kernel, arg)
                print(_g(f"  deleted '{arg}'"))

        elif sub == "cat":
            if not arg:
                print(_r("  usage: cat <name>"))
                continue
            if not arg.endswith(".txt"):
                arg += ".txt"
            content = _load_note(kernel, arg)
            if not content:
                print(_d("  (empty or not found)"))
            else:
                print()
                for i, l in enumerate(content.splitlines(), 1):
                    print(f"  {_d(str(i).rjust(3))}  {l}")
                print()

        else:
            print(_r(f"  unknown command '{sub}'"))

    print(_d("  notes: bye"))
    print()
