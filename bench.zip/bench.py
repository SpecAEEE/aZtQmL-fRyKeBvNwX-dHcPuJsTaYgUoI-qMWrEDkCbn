"""
bench.py — system benchmark for Flux OS
fpt install bench
"""

MANIFEST = {
    "name":        "bench",
    "version":     "1.0.0",
    "description": "CPU, memory and filesystem benchmark suite",
    "commands":    ["bench"],
    "author":      "FluxTeam",
}

import time, math, random, hashlib

_ANSI_R  = "\033[0m"
_ANSI_G  = "\033[92m"
_ANSI_C  = "\033[96m"
_ANSI_Y  = "\033[93m"
_ANSI_D  = "\033[2m"
_ANSI_RE = "\033[91m"

def _g(t): return f"{_ANSI_G}{t}{_ANSI_R}"
def _c(t): return f"{_ANSI_C}{t}{_ANSI_R}"
def _y(t): return f"{_ANSI_Y}{t}{_ANSI_R}"
def _d(t): return f"{_ANSI_D}{t}{_ANSI_R}"
def _r(t): return f"{_ANSI_RE}{t}{_ANSI_R}"


def _bar(score, max_score=10000, width=28):
    frac = min(score / max_score, 1.0)
    filled = int(frac * width)
    if frac > 0.75:   colour = _ANSI_G
    elif frac > 0.4:  colour = _ANSI_Y
    else:             colour = _ANSI_RE
    bar = colour + "█" * filled + _ANSI_D + "░" * (width - filled) + _ANSI_R
    return f"[{bar}]"


def _bench_cpu():
    """Integer arithmetic throughput."""
    N = 500_000
    t0 = time.perf_counter()
    acc = 0
    for i in range(N):
        acc += i * 3 - i // 2 + (i % 7)
    elapsed = time.perf_counter() - t0
    ops_per_sec = N / elapsed
    score = min(int(ops_per_sec / 50), 10000)
    return elapsed, ops_per_sec, score


def _bench_float():
    """Floating-point / trig throughput."""
    N = 200_000
    t0 = time.perf_counter()
    acc = 0.0
    for i in range(1, N + 1):
        acc += math.sin(i) * math.cos(i) + math.sqrt(i)
    elapsed = time.perf_counter() - t0
    ops_per_sec = N / elapsed
    score = min(int(ops_per_sec / 20), 10000)
    return elapsed, ops_per_sec, score


def _bench_hash():
    """SHA-256 hashing throughput."""
    N = 5_000
    data = b"FluxBench" * 64
    t0 = time.perf_counter()
    for _ in range(N):
        hashlib.sha256(data).digest()
    elapsed = time.perf_counter() - t0
    hashes_per_sec = N / elapsed
    score = min(int(hashes_per_sec / 5), 10000)
    return elapsed, hashes_per_sec, score


def _bench_memory():
    """List allocation + random access."""
    N = 100_000
    t0 = time.perf_counter()
    buf = [random.random() for _ in range(N)]
    s = 0.0
    for _ in range(N):
        s += buf[random.randint(0, N - 1)]
    elapsed = time.perf_counter() - t0
    score = min(int(N / elapsed / 10), 10000)
    return elapsed, N, score


def _bench_fs(kernel):
    """FluxFS write + read speed (virtual blocks)."""
    N = 50
    payload = "X" * 1024  # 1 KB
    paths = []
    t0 = time.perf_counter()
    for i in range(N):
        p = f"/tmp/bench_{i}.tmp"
        kernel.fs.create_file("MainPartition", p, content=payload)
        paths.append(p)
    write_elapsed = time.perf_counter() - t0

    t1 = time.perf_counter()
    for p in paths:
        kernel.fs.read_file("MainPartition", p)
    read_elapsed = time.perf_counter() - t1

    # cleanup
    for p in paths:
        kernel.fs.delete("MainPartition", p, recursive=False)

    write_kb_s = (N * 1) / write_elapsed
    read_kb_s  = (N * 1) / read_elapsed
    score = min(int((write_kb_s + read_kb_s) / 2), 10000)
    return write_elapsed, read_elapsed, write_kb_s, read_kb_s, score


def _grade(score):
    if score >= 8000: return _g("S  (excellent)")
    if score >= 6000: return _g("A  (great)")
    if score >= 4000: return _y("B  (good)")
    if score >= 2000: return _y("C  (average)")
    return _r("D  (slow)")


def run(kernel):
    print()
    print(_c("  FluxBench 1.0 — System Benchmark Suite"))
    print(_d("  " + "─" * 52))
    print(_d("  Running 5 tests... this will take a few seconds."))
    print()

    results = {}
    tests = [
        ("CPU  (integer)", _bench_cpu),
        ("CPU  (float)",   _bench_float),
        ("CPU  (hashing)", _bench_hash),
        ("Memory",         _bench_memory),
    ]

    for label, fn in tests:
        print(f"  {_d('running')}  {label:<20}", end="", flush=True)
        data = fn()
        score = data[-1]
        results[label] = score
        print(f"\r  {_g('done')}     {label:<20} {_bar(score)}  {score:>5} pts  {_grade(score)}")

    # FS bench
    print(f"  {_d('running')}  {'FluxFS I/O':<20}", end="", flush=True)
    fs_data = _bench_fs(kernel)
    fs_score = fs_data[-1]
    results["FluxFS I/O"] = fs_score
    write_kb, read_kb = fs_data[2], fs_data[3]
    print(f"\r  {_g('done')}     {'FluxFS I/O':<20} {_bar(fs_score)}  {fs_score:>5} pts  {_grade(fs_score)}")

    # ── Summary ───────────────────────────────────────────────────────────────
    total = sum(results.values())
    avg   = total // len(results)

    print()
    print(_d("  " + "─" * 52))
    print(f"  {'Total score':<28} {_g(str(total))} pts")
    print(f"  {'Average':<28} {_g(str(avg))} pts")
    print(f"  {'FluxFS write':<28} {write_kb:.1f} KB/s")
    print(f"  {'FluxFS read':<28}  {read_kb:.1f} KB/s")
    print()
    print(f"  Overall grade:  {_grade(avg)}")
    print()

    # Store result in FluxFS as a log
    import datetime
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{ts}] total={total} avg={avg} " + " ".join(f"{k}={v}" for k, v in results.items())
    kernel.fs.mkdir("MainPartition", "/private/var/log")
    ok, existing = kernel.fs.read_file("MainPartition", "/private/var/log/bench.log")
    prev = existing if ok else ""
    kernel.fs.create_file("MainPartition", "/private/var/log/bench.log",
                           content=(prev + "\n" + log_line).strip())
    print(_d(f"  Result saved to /private/var/log/bench.log"))
    print()
