"""
pip.py — simulated pip package manager for Flux OS
fpt install pip
"""

MANIFEST = {
    "name":        "pip",
    "version":     "23.3.1",
    "description": "Python package installer — installs into FluxFS Python environment",
    "commands":    ["pip", "pip3"],
    "author":      "FluxTeam",
}

import time, random, json

_ANSI_R  = "\033[0m"
_ANSI_G  = "\033[92m"
_ANSI_C  = "\033[96m"
_ANSI_Y  = "\033[93m"
_ANSI_D  = "\033[2m"
_ANSI_RE = "\033[91m"

def _g(t): return f"{_ANSI_G}{t}{_ANSI_R}"
def _c(t): return f"{_ANSI_C}{t}{_ANSI_R}"
def _y(t): return f"{_ANSI_Y}{t}{_ANSI_R}"
def _d(t): return f"{_ANSI_D}{t}{_ANSI_R}"
def _r(t): return f"{_ANSI_RE}{t}{_ANSI_R}"

REGISTRY_PATH = "/usr/lib/python3.11/pip_registry.json"
SITE_PACKAGES = "/usr/lib/python3.11/site-packages"

# ── Known package database ────────────────────────────────────────────────────
# Realistic metadata for popular packages. Any unknown package will get
# a generated stub entry so pip install always "works".
KNOWN_PACKAGES = {
    "numpy": {
        "version": "1.26.4", "size_kb": 17200,
        "summary": "Fundamental package for array computing with Python.",
        "deps": [],
        "modules": ["numpy"],
    },
    "pandas": {
        "version": "2.2.0", "size_kb": 28900,
        "summary": "Powerful data structures for data analysis.",
        "deps": ["numpy", "python-dateutil", "pytz"],
        "modules": ["pandas"],
    },
    "requests": {
        "version": "2.31.0", "size_kb": 890,
        "summary": "Python HTTP for Humans.",
        "deps": ["urllib3", "certifi", "charset-normalizer", "idna"],
        "modules": ["requests"],
    },
    "flask": {
        "version": "3.0.2", "size_kb": 640,
        "summary": "A simple framework for building complex web applications.",
        "deps": ["werkzeug", "jinja2", "click", "itsdangerous", "blinker"],
        "modules": ["flask"],
    },
    "django": {
        "version": "5.0.2", "size_kb": 10200,
        "summary": "A high-level Python web framework.",
        "deps": ["sqlparse", "asgiref"],
        "modules": ["django"],
    },
    "scipy": {
        "version": "1.12.0", "size_kb": 36100,
        "summary": "Fundamental algorithms for scientific computing.",
        "deps": ["numpy"],
        "modules": ["scipy"],
    },
    "matplotlib": {
        "version": "3.8.3", "size_kb": 12300,
        "summary": "Comprehensive library for creating visualizations.",
        "deps": ["numpy", "pillow", "pyparsing", "cycler"],
        "modules": ["matplotlib"],
    },
    "sklearn": {
        "version": "1.4.1", "size_kb": 9800,
        "summary": "Simple and efficient tools for machine learning.",
        "deps": ["numpy", "scipy", "joblib", "threadpoolctl"],
        "modules": ["sklearn", "scikit-learn"],
    },
    "scikit-learn": {
        "version": "1.4.1", "size_kb": 9800,
        "summary": "Simple and efficient tools for machine learning.",
        "deps": ["numpy", "scipy", "joblib"],
        "modules": ["sklearn"],
    },
    "tensorflow": {
        "version": "2.16.1", "size_kb": 589000,
        "summary": "An end-to-end open source machine learning platform.",
        "deps": ["numpy", "protobuf", "h5py", "keras"],
        "modules": ["tensorflow", "tf"],
    },
    "torch": {
        "version": "2.2.1", "size_kb": 776000,
        "summary": "Tensors and dynamic neural networks with GPU acceleration.",
        "deps": ["numpy", "sympy", "networkx", "jinja2"],
        "modules": ["torch"],
    },
    "pillow": {
        "version": "10.2.0", "size_kb": 3400,
        "summary": "Python Imaging Library (PIL) fork.",
        "deps": [],
        "modules": ["PIL"],
    },
    "sqlalchemy": {
        "version": "2.0.28", "size_kb": 6100,
        "summary": "Database Abstraction Library.",
        "deps": ["greenlet"],
        "modules": ["sqlalchemy"],
    },
    "fastapi": {
        "version": "0.110.0", "size_kb": 810,
        "summary": "FastAPI framework, high performance, easy to learn.",
        "deps": ["starlette", "pydantic", "anyio"],
        "modules": ["fastapi"],
    },
    "pydantic": {
        "version": "2.6.3", "size_kb": 2100,
        "summary": "Data validation using Python type annotations.",
        "deps": ["pydantic-core", "annotated-types", "typing-extensions"],
        "modules": ["pydantic"],
    },
    "pytest": {
        "version": "8.0.2", "size_kb": 1200,
        "summary": "The pytest framework for testing.",
        "deps": ["iniconfig", "packaging", "pluggy"],
        "modules": ["pytest", "_pytest"],
    },
    "celery": {
        "version": "5.3.6", "size_kb": 2800,
        "summary": "Distributed task queue.",
        "deps": ["billiard", "kombu", "vine"],
        "modules": ["celery"],
    },
    "redis": {
        "version": "5.0.2", "size_kb": 560,
        "summary": "Python client for Redis.",
        "deps": [],
        "modules": ["redis"],
    },
    "boto3": {
        "version": "1.34.51", "size_kb": 1100,
        "summary": "AWS SDK for Python.",
        "deps": ["botocore", "jmespath", "s3transfer"],
        "modules": ["boto3"],
    },
    "cryptography": {
        "version": "42.0.4", "size_kb": 4200,
        "summary": "Cryptographic recipes and primitives.",
        "deps": ["cffi"],
        "modules": ["cryptography"],
    },
    "aiohttp": {
        "version": "3.9.3", "size_kb": 2600,
        "summary": "Async HTTP client/server framework.",
        "deps": ["aiosignal", "attrs", "multidict", "yarl"],
        "modules": ["aiohttp"],
    },
    "httpx": {
        "version": "0.27.0", "size_kb": 480,
        "summary": "A next-generation HTTP client for Python.",
        "deps": ["certifi", "httpcore", "anyio"],
        "modules": ["httpx"],
    },
    "rich": {
        "version": "13.7.1", "size_kb": 860,
        "summary": "Render rich text and beautiful formatting in the terminal.",
        "deps": ["markdown-it-py", "pygments"],
        "modules": ["rich"],
    },
    "click": {
        "version": "8.1.7", "size_kb": 350,
        "summary": "Composable command line interface toolkit.",
        "deps": [],
        "modules": ["click"],
    },
    "typer": {
        "version": "0.9.0", "size_kb": 210,
        "summary": "Build great CLIs with type hints.",
        "deps": ["click"],
        "modules": ["typer"],
    },
    "pyyaml": {
        "version": "6.0.1", "size_kb": 280,
        "summary": "YAML parser and emitter for Python.",
        "deps": [],
        "modules": ["yaml"],
    },
    "dotenv": {
        "version": "1.0.1", "size_kb": 95,
        "summary": "Read key-value pairs from a .env file.",
        "deps": [],
        "modules": ["dotenv"],
    },
    "python-dotenv": {
        "version": "1.0.1", "size_kb": 95,
        "summary": "Read key-value pairs from a .env file.",
        "deps": [],
        "modules": ["dotenv"],
    },
    "tqdm": {
        "version": "4.66.2", "size_kb": 280,
        "summary": "Fast, extensible progress bar.",
        "deps": [],
        "modules": ["tqdm"],
    },
    "sympy": {
        "version": "1.12", "size_kb": 6400,
        "summary": "Python library for symbolic mathematics.",
        "deps": ["mpmath"],
        "modules": ["sympy"],
    },
    "networkx": {
        "version": "3.2.1", "size_kb": 2900,
        "summary": "Network analysis in Python.",
        "deps": [],
        "modules": ["networkx"],
    },
    "pygame": {
        "version": "2.5.2", "size_kb": 9800,
        "summary": "Python game development.",
        "deps": [],
        "modules": ["pygame"],
    },
    "openai": {
        "version": "1.14.0", "size_kb": 1200,
        "summary": "OpenAI Python API library.",
        "deps": ["httpx", "pydantic", "tqdm"],
        "modules": ["openai"],
    },
    "anthropic": {
        "version": "0.21.0", "size_kb": 980,
        "summary": "Anthropic Python API library.",
        "deps": ["httpx", "pydantic"],
        "modules": ["anthropic"],
    },
    "langchain": {
        "version": "0.1.12", "size_kb": 4100,
        "summary": "Building applications with LLMs through composability.",
        "deps": ["pydantic", "requests", "aiohttp", "tenacity"],
        "modules": ["langchain"],
    },
    "transformers": {
        "version": "4.38.2", "size_kb": 8700,
        "summary": "State-of-the-art Machine Learning for JAX, PyTorch and TensorFlow.",
        "deps": ["numpy", "tqdm", "pyyaml", "regex", "tokenizers"],
        "modules": ["transformers"],
    },
}

# ── Registry helpers ──────────────────────────────────────────────────────────

def _load_registry(kernel) -> list:
    ok, content = kernel.fs.read_file("MainPartition", REGISTRY_PATH)
    if ok:
        try: return json.loads(content)
        except: pass
    return []


def _save_registry(kernel, reg: list):
    kernel.fs.mkdir("MainPartition", "/usr/lib/python3.11")
    kernel.fs.create_file("MainPartition", REGISTRY_PATH,
                           content=json.dumps(reg, indent=2))


def _reg_get(reg: list, name: str):
    return next((p for p in reg if p["name"] == name), None)


def _pkg_info(name: str) -> dict:
    """Return metadata for a known or unknown package."""
    if name in KNOWN_PACKAGES:
        info = dict(KNOWN_PACKAGES[name])
        info["name"] = name
        return info
    # generate a plausible stub for unknown packages
    return {
        "name":     name,
        "version":  f"{random.randint(0,3)}.{random.randint(0,9)}.{random.randint(0,9)}",
        "size_kb":  random.randint(50, 2000),
        "summary":  f"{name} Python package.",
        "deps":     [],
        "modules":  [name.replace("-", "_")],
    }


# ── Progress bar ──────────────────────────────────────────────────────────────

def _progress(label: str, total_kb: int, colour=_ANSI_G):
    width = 30
    steps = 20
    for i in range(steps + 1):
        filled = int(i / steps * width)
        bar  = colour + "━" * filled + _ANSI_D + "╌" * (width - filled) + _ANSI_R
        pct  = int(i / steps * 100)
        kb   = int(i / steps * total_kb)
        print(f"\r  {_d(label):<36} [{bar}] {pct:>3}%  {kb:>6} KB", end="", flush=True)
        time.sleep(random.uniform(0.01, 0.06))
    print()


# ── Install ───────────────────────────────────────────────────────────────────

def _install(kernel, pkg_name: str, reg: list, quiet=False, upgrade=False) -> bool:
    info = _pkg_info(pkg_name)
    existing = _reg_get(reg, pkg_name)

    if existing and not upgrade:
        if not quiet:
            print(_y(f"  Requirement already satisfied: {pkg_name}=={existing['version']}"))
        return True

    if not quiet:
        print(_d(f"  Collecting {pkg_name}"))
        time.sleep(0.15)
        print(_d(f"    Downloading {pkg_name}-{info['version']}-py3-none-any.whl ({info['size_kb']} kB)"))
        _progress(f"    {pkg_name}-{info['version']}", info["size_kb"])

    # install deps silently first
    for dep in info.get("deps", []):
        if not _reg_get(reg, dep):
            _install(kernel, dep, reg, quiet=True)

    if not quiet:
        print(_d(f"  Installing collected packages: {pkg_name}"))

    # write a stub __init__.py into FluxFS site-packages
    stub_dir  = f"{SITE_PACKAGES}/{pkg_name}"
    stub_init = f"{stub_dir}/__init__.py"
    kernel.fs.mkdir("MainPartition", SITE_PACKAGES)
    kernel.fs.mkdir("MainPartition", stub_dir)
    stub_src = (
        f'"""FluxPy stub for {pkg_name} {info["version"]}"""\n'
        f'__version__ = "{info["version"]}"\n'
        f'__author__  = "PyPI"\n'
        f'# This is a simulated package inside FluxOS.\n'
    )
    kernel.fs.create_file("MainPartition", stub_init, content=stub_src)

    # write dist-info
    dist_dir = f"{SITE_PACKAGES}/{pkg_name}-{info['version']}.dist-info"
    kernel.fs.mkdir("MainPartition", dist_dir)
    kernel.fs.create_file("MainPartition", f"{dist_dir}/METADATA",
        content=f"Metadata-Version: 2.1\nName: {pkg_name}\nVersion: {info['version']}\nSummary: {info['summary']}\n")

    # update registry
    entry = {
        "name":     pkg_name,
        "version":  info["version"],
        "summary":  info["summary"],
        "location": stub_dir,
        "modules":  info.get("modules", [pkg_name]),
    }
    reg = [p for p in reg if p["name"] != pkg_name]
    reg.append(entry)
    _save_registry(kernel, reg)

    if not quiet:
        action = "Successfully upgraded" if (existing and upgrade) else "Successfully installed"
        print(_g(f"  {action} {pkg_name}-{info['version']}"))

    return True


# ── Uninstall ─────────────────────────────────────────────────────────────────

def _uninstall(kernel, pkg_name: str, reg: list, yes=False):
    entry = _reg_get(reg, pkg_name)
    if not entry:
        print(_r(f"  WARNING: Skipping {pkg_name} as it is not installed.")); return

    if not yes:
        locs = entry.get("location", SITE_PACKAGES + "/" + pkg_name)
        print(f"  Found existing installation: {pkg_name} {entry['version']}")
        print(f"    Uninstalling {pkg_name}-{entry['version']}:")
        print(f"      Would remove: {locs}/*")
        try:
            confirm = input(_y("  Proceed (Y/n)? ")).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print(); return
        if confirm not in ("", "y", "yes"):
            print(_d("  Aborted.")); return

    # remove from FluxFS
    stub_dir = entry.get("location", f"{SITE_PACKAGES}/{pkg_name}")
    kernel.fs.delete("MainPartition", stub_dir, recursive=True)
    dist_dir = f"{SITE_PACKAGES}/{pkg_name}-{entry['version']}.dist-info"
    kernel.fs.delete("MainPartition", dist_dir, recursive=True)

    reg = [p for p in reg if p["name"] != pkg_name]
    _save_registry(kernel, reg)
    print(_g(f"  Successfully uninstalled {pkg_name}-{entry['version']}"))


# ── List ──────────────────────────────────────────────────────────────────────

def _list_pkgs(kernel, reg: list, fmt="columns"):
    if not reg:
        print(_d("  (no packages installed)")); return
    if fmt == "json":
        data = [{"name": p["name"], "version": p["version"]} for p in sorted(reg, key=lambda x: x["name"])]
        print(json.dumps(data, indent=2)); return
    print()
    print(_d(f"  {'Package':<32} Version"))
    print(_d("  " + "─" * 44))
    for p in sorted(reg, key=lambda x: x["name"]):
        print(f"  {_g(p['name']):<40} {p['version']}")
    print()


# ── Show ──────────────────────────────────────────────────────────────────────

def _show(kernel, pkg_name: str, reg: list):
    entry = _reg_get(reg, pkg_name)
    if not entry:
        print(_r(f"  WARNING: Package(s) not found: {pkg_name}")); return
    info = _pkg_info(pkg_name)
    print()
    print(f"  {_c('Name')}:         {entry['name']}")
    print(f"  {_c('Version')}:      {entry['version']}")
    print(f"  {_c('Summary')}:      {entry.get('summary', info.get('summary',''))}")
    print(f"  {_c('Location')}:     {entry.get('location', SITE_PACKAGES + '/' + pkg_name)}")
    print(f"  {_c('Requires')}:     {', '.join(info.get('deps', [])) or 'none'}")
    print()


# ── Search (PyPI-like) ────────────────────────────────────────────────────────

def _search(query: str):
    print()
    print(_y("  NOTE: pip search was removed from pip 21.0. Use https://pypi.org instead."))
    print(_d("  (Flux mirrors the real pip behaviour here)"))
    print()


# ── Main entry ────────────────────────────────────────────────────────────────

def _print_usage():
    print()
    print(_c("  pip 23.3.1  (FluxOS)"))
    print(_d("  " + "─" * 52))
    cmds = [
        ("install <pkg> [pkg2 ...]",  "install packages"),
        ("install <pkg> --upgrade",   "upgrade a package"),
        ("install <pkg> --quiet",     "install silently"),
        ("uninstall <pkg>",           "remove a package"),
        ("uninstall <pkg> -y",        "remove without prompt"),
        ("list",                      "list installed packages"),
        ("list --format=json",        "list as JSON"),
        ("show <pkg>",                "show package info"),
        ("freeze",                    "output installed packages (requirements format)"),
        ("search <query>",            "search PyPI (deprecated)"),
    ]
    for cmd, desc in cmds:
        print(f"  {_g('pip ' + cmd):<44} {_d(desc)}")
    print()


def run(kernel):
    reg = _load_registry(kernel)

    print()
    print(_c("  FluxPip 23.3.1") + _d(" — Python package manager (FluxOS sandbox)"))
    print(_d("  Packages are installed into the FluxFS Python environment."))
    print(_d("  Type 'exit' to quit."))
    print()

    while True:
        try:
            line = input(_y("  pip> ")).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break

        if not line: continue
        if line in ("exit", "quit", "q"): break

        # strip leading "pip " or "pip3 " if user types it
        if line.startswith("pip3 "): line = line[5:]
        elif line.startswith("pip "):  line = line[4:]

        parts = line.split()
        if not parts: continue
        sub   = parts[0]
        rest  = parts[1:]

        # ── install ───────────────────────────────────────────────────────────
        if sub == "install":
            pkgs    = [p for p in rest if not p.startswith("-")]
            upgrade = "--upgrade" in rest or "-U" in rest
            quiet   = "--quiet"   in rest or "-q" in rest

            if not pkgs:
                print(_r("  ERROR: You must give at least one requirement to install.")); continue

            for pkg in pkgs:
                # handle pkg==version syntax
                name = pkg.split("==")[0].split(">=")[0].split("<=")[0].split("~=")[0]
                _install(kernel, name, reg, quiet=quiet, upgrade=upgrade)
                reg = _load_registry(kernel)  # reload after each install

        # ── uninstall ─────────────────────────────────────────────────────────
        elif sub == "uninstall":
            pkgs = [p for p in rest if not p.startswith("-")]
            yes  = "-y" in rest or "--yes" in rest
            if not pkgs:
                print(_r("  ERROR: You must give at least one package to uninstall.")); continue
            for pkg in pkgs:
                _uninstall(kernel, pkg, reg, yes=yes)
                reg = _load_registry(kernel)

        # ── list ──────────────────────────────────────────────────────────────
        elif sub == "list":
            fmt = "json" if "--format=json" in rest else "columns"
            _list_pkgs(kernel, reg, fmt=fmt)

        # ── show ──────────────────────────────────────────────────────────────
        elif sub == "show":
            if not rest: print(_r("  ERROR: Please provide a package name.")); continue
            for pkg in rest:
                _show(kernel, pkg, reg)

        # ── freeze ────────────────────────────────────────────────────────────
        elif sub == "freeze":
            for p in sorted(reg, key=lambda x: x["name"]):
                print(f"  {p['name']}=={p['version']}")

        # ── search ────────────────────────────────────────────────────────────
        elif sub == "search":
            _search(" ".join(rest))

        # ── help / unknown ────────────────────────────────────────────────────
        elif sub in ("help", "--help", "-h"):
            _print_usage()

        else:
            print(_r(f"  ERROR: unknown command '{sub}' - see 'pip help'"))

    print(_d("  pip: bye"))
    print()
