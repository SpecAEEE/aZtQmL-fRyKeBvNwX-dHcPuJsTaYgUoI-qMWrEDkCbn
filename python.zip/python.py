"""
python.py — simulated Python REPL for Flux OS
fpt install python
"""

MANIFEST = {
    "name":        "python",
    "version":     "3.11.0",
    "description": "Sandboxed Python REPL with FluxFS integration",
    "commands":    ["python", "python3"],
    "author":      "FluxTeam",
}

import sys, os, traceback, time, re, builtins, types

_ANSI_R  = "\033[0m"
_ANSI_G  = "\033[92m"
_ANSI_C  = "\033[96m"
_ANSI_Y  = "\033[93m"
_ANSI_D  = "\033[2m"
_ANSI_RE = "\033[91m"
_ANSI_W  = "\033[97m"
_ANSI_M  = "\033[95m"

def _g(t): return f"{_ANSI_G}{t}{_ANSI_R}"
def _c(t): return f"{_ANSI_C}{t}{_ANSI_R}"
def _y(t): return f"{_ANSI_Y}{t}{_ANSI_R}"
def _d(t): return f"{_ANSI_D}{t}{_ANSI_R}"
def _r(t): return f"{_ANSI_RE}{t}{_ANSI_R}"
def _m(t): return f"{_ANSI_M}{t}{_ANSI_R}"

FLUX_PYLIB = "/usr/lib/python3.11"
FLUX_SITE  = "/usr/lib/python3.11/site-packages"

# ── Modules that are always available (real ones, safe to expose) ─────────────
_REAL_SAFE = {
    "math", "random", "time", "datetime", "json", "re",
    "string", "collections", "itertools", "functools",
    "hashlib", "base64", "struct", "io", "copy",
    "statistics", "fractions", "decimal", "enum",
    "dataclasses", "typing", "abc", "operator",
}

# ── Stub modules for pip-installed packages ───────────────────────────────────
class _StubModule(types.ModuleType):
    """A believable stub for a pip-installed package."""
    def __init__(self, name, version="0.0.0"):
        super().__init__(name)
        self._version  = version
        self.__version__ = version
        self.__path__    = [f"{FLUX_SITE}/{name}"]
        self.__file__    = f"{FLUX_SITE}/{name}/__init__.py"

    def __getattr__(self, item):
        # return a callable stub for anything accessed
        def _stub(*a, **kw):
            return _StubModule(f"{self.__name__}.{item}")
        _stub.__name__ = item
        return _stub

    def __call__(self, *a, **kw):
        return self

    def __repr__(self):
        return f"<module '{self.__name__}' (flux-stub) version {self._version}>"

    def __iter__(self): return iter([])
    def __len__(self):  return 0


# ── FluxFS file object (returned by open() inside the REPL) ──────────────────
class _FluxFile:
    def __init__(self, path, mode, kernel):
        self._path   = path
        self._mode   = mode
        self._kernel = kernel
        self._closed = False
        self._buf    = ""
        if "r" in mode:
            ok, content = kernel.fs.read_file("MainPartition", path)
            self._buf = content if ok else ""
            self._pos = 0
        else:
            self._pos = 0
            if "a" in mode:
                ok, content = kernel.fs.read_file("MainPartition", path)
                self._buf = content if ok else ""
                self._pos = len(self._buf)

    def read(self, n=-1):
        if n == -1: data = self._buf[self._pos:]; self._pos = len(self._buf)
        else:       data = self._buf[self._pos:self._pos+n]; self._pos += n
        return data

    def readline(self):
        end = self._buf.find("\n", self._pos)
        if end == -1: line = self._buf[self._pos:]; self._pos = len(self._buf)
        else:         line = self._buf[self._pos:end+1]; self._pos = end + 1
        return line

    def readlines(self): return self._buf[self._pos:].splitlines(keepends=True)

    def write(self, data):
        if "r" in self._mode and "+" not in self._mode:
            raise IOError("file not open for writing")
        self._buf += data
        return len(data)

    def writelines(self, lines):
        for l in lines: self.write(l)

    def flush(self):
        if "w" in self._mode or "a" in self._mode or "+" in self._mode:
            self._kernel.fs.create_file("MainPartition", self._path,
                                        content=self._buf)

    def close(self):
        if not self._closed:
            self.flush()
            self._closed = True

    def __enter__(self): return self
    def __exit__(self, *a): self.close()
    def __iter__(self): return iter(self.readlines())
    def __repr__(self): return f"<FluxFile '{self._path}' mode='{self._mode}'>"


# ── Build the sandbox globals ─────────────────────────────────────────────────
def _build_globals(kernel, pip_registry: dict):
    import math, random, time, datetime, json, re, string
    import collections, itertools, functools, hashlib, base64
    import statistics, fractions, decimal, copy, io

    real_modules = {
        "math": math, "random": random, "time": time,
        "datetime": datetime, "json": json, "re": re,
        "string": string, "collections": collections,
        "itertools": itertools, "functools": functools,
        "hashlib": hashlib, "base64": base64,
        "statistics": statistics, "fractions": fractions,
        "decimal": decimal, "copy": copy, "io": io,
    }

    def _flux_import(name, *a, **kw):
        if name in real_modules:
            return real_modules[name]
        if name in pip_registry:
            entry = pip_registry[name]
            stub = _StubModule(name, entry.get("version","1.0.0"))
            return stub
        raise ModuleNotFoundError(
            f"No module named '{name}'\n"
            f"  Hint: run  pip install {name}  to install it first."
        )

    def _flux_open(path, mode="r", **kw):
        if not path.startswith("/"):
            path = "/home/" + path
        return _FluxFile(path, mode, kernel)

    # safe builtins — remove anything dangerous
    safe_builtins = {}
    _blocked = {"exec", "eval", "compile", "__import__",
                 "open", "input", "__loader__", "__spec__"}
    for k in dir(builtins):
        if k not in _blocked:
            safe_builtins[k] = getattr(builtins, k)
    safe_builtins["__import__"] = _flux_import
    safe_builtins["open"]       = _flux_open
    safe_builtins["input"]      = input   # allow input() in scripts

    globs = {
        "__name__":     "__main__",
        "__builtins__": safe_builtins,
        "__flux_kernel__": kernel,
    }
    # inject real safe modules directly so `import math` stub works
    # AND so `math.sin(x)` works without importing
    globs.update(real_modules)

    return globs


# ── Multi-line input helper ───────────────────────────────────────────────────
def _is_incomplete(src: str) -> bool:
    """Return True if the source looks like it needs more lines."""
    import codeop
    try:
        result = codeop.compile_command(src, "<stdin>", "single")
        return result is None
    except SyntaxError:
        return False


# ── Run a .py file from FluxFS ────────────────────────────────────────────────
def _run_file(path, kernel, globs):
    ok, content = kernel.fs.read_file("MainPartition", path)
    if not ok:
        print(_r(f"python: can't open file '{path}': No such file or directory"))
        return
    print(_d(f"  Running {path}..."))
    try:
        code = compile(content, path, "exec")
        exec(code, globs)   # noqa: S102
    except SystemExit:
        pass
    except Exception:
        tb = traceback.format_exc()
        # clean up internal flux frames
        tb_lines = [l for l in tb.splitlines()
                    if 'flux' not in l.lower() or 'File "' in l]
        print(_r("\n".join(tb_lines)))


# ── REPL loop ─────────────────────────────────────────────────────────────────
def _repl(kernel, pip_registry):
    globs   = _build_globals(kernel, pip_registry)
    buf     = []
    history = []

    print()
    print(_g("Python 3.11.0") + _d(" (FluxOS sandbox) [FluxPy/1.0]"))
    print(_d('Type "help", "copyright", "exit()" or "quit" to exit.'))
    print(_d('Use open("/path") to access FluxFS files.'))
    print()

    while True:
        prompt = _m("... ") if buf else _m(">>> ")
        try:
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            if buf:
                buf.clear(); print(); continue
            print(); break

        if not buf and line.strip() in ("exit()", "quit()", "exit", "quit"):
            break

        if not buf and line.strip() == "":
            continue

        buf.append(line)
        src = "\n".join(buf)

        # check if block is complete
        if _is_incomplete(src):
            continue

        if src.strip():
            history.append(src)

        # try eval first (expression → print result), then exec (statement)
        try:
            try:
                code = compile(src, "<stdin>", "eval")
                result = eval(code, globs)   # noqa: S307
                if result is not None:
                    print(repr(result))
            except SyntaxError:
                code = compile(src, "<stdin>", "exec")
                exec(code, globs)            # noqa: S102
        except SystemExit:
            buf.clear(); break
        except KeyboardInterrupt:
            print(_r("KeyboardInterrupt"))
        except Exception:
            tb = traceback.format_exc()
            lines = tb.splitlines()
            # strip internal sandbox frames to keep tracebacks clean
            clean = []
            skip_next = False
            for l in lines:
                if skip_next and l.startswith("    "):
                    skip_next = False; continue
                if "in _repl" in l or "in _build_globals" in l:
                    skip_next = True; continue
                clean.append(l)
            print(_r("\n".join(clean)))

        buf.clear()

    print(_d("  python: exit"))
    print()


# ── Entry point ───────────────────────────────────────────────────────────────
def run(kernel):
    # load pip registry from FluxFS
    pip_registry = {}
    ok, content = kernel.fs.read_file("MainPartition", "/usr/lib/python3.11/pip_registry.json")
    if ok:
        try:
            import json as _json
            pip_registry = {p["name"]: p for p in _json.loads(content)}
        except Exception:
            pass

    # check for script argument via a tiny argv hack
    # packages can't receive CLI args directly, so we check the FluxFS
    # for a special launch file written by a wrapper
    _repl(kernel, pip_registry)
