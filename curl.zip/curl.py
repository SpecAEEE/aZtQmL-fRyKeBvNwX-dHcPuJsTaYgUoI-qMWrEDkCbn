"""
curl.py — real HTTP fetcher for Flux OS
fpt install curl
"""

MANIFEST = {
    "name":        "curl",
    "version":     "1.0.0",
    "description": "Fetch real URLs and optionally save to FluxFS",
    "commands":    ["curl"],
    "author":      "FluxTeam",
}

import urllib.request, urllib.error, sys, time, re

_ANSI_R  = "\033[0m"
_ANSI_G  = "\033[92m"
_ANSI_C  = "\033[96m"
_ANSI_Y  = "\033[93m"
_ANSI_D  = "\033[2m"
_ANSI_RE = "\033[91m"

def _g(t): return f"{_ANSI_G}{t}{_ANSI_R}"
def _c(t): return f"{_ANSI_C}{t}{_ANSI_R}"
def _y(t): return f"{_ANSI_Y}{t}{_ANSI_R}"
def _d(t): return f"{_ANSI_D}{t}{_ANSI_R}"
def _r(t): return f"{_ANSI_RE}{t}{_ANSI_R}"

MAX_BODY_BYTES = 32 * 1024   # 32 KB display limit
TIMEOUT        = 10

HEADERS = {
    "User-Agent": "FluxOS/1.0 curl/1.0",
    "Accept":     "text/plain, text/html, application/json, */*",
}


def _strip_html(text):
    """Very basic HTML → plain text."""
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<p[^>]*>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<h[1-6][^>]*>", "\n### ", text, flags=re.IGNORECASE)
    text = re.sub(r"<li[^>]*>", "\n  • ", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"&amp;",  "&",  text)
    text = re.sub(r"&lt;",   "<",  text)
    text = re.sub(r"&gt;",   ">",  text)
    text = re.sub(r"&quot;", '"',  text)
    text = re.sub(r"&#39;",  "'",  text)
    text = re.sub(r"&nbsp;", " ",  text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _do_fetch(url, method="GET", show_headers=False, strip_html=True):
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    req = urllib.request.Request(url, headers=HEADERS, method=method)

    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            elapsed   = time.perf_counter() - t0
            status    = resp.status
            reason    = resp.reason
            resp_hdrs = dict(resp.headers)
            raw_body  = resp.read(MAX_BODY_BYTES)
            truncated = len(raw_body) == MAX_BODY_BYTES
    except urllib.error.HTTPError as e:
        return None, None, None, str(e), 0
    except urllib.error.URLError as e:
        return None, None, None, str(e.reason), 0
    except Exception as e:
        return None, None, None, str(e), 0

    content_type = resp_hdrs.get("Content-Type", "")
    charset = "utf-8"
    if "charset=" in content_type:
        charset = content_type.split("charset=")[-1].split(";")[0].strip()

    try:
        body = raw_body.decode(charset, errors="replace")
    except LookupError:
        body = raw_body.decode("utf-8", errors="replace")

    is_html = "html" in content_type.lower()
    if strip_html and is_html:
        body = _strip_html(body)

    return status, reason, resp_hdrs, body, elapsed


def _print_usage():
    print()
    print(_c("  curl — Flux HTTP client"))
    print(_d("  " + "─" * 48))
    print(f"  {_g('curl <url>'):<38} fetch and display")
    print(f"  {_g('curl <url> -o <file>'):<38} save to FluxFS")
    print(f"  {_g('curl <url> -I'):<38} headers only")
    print(f"  {_g('curl <url> --raw'):<38} skip HTML stripping")
    print(f"  {_g('curl <url> -s'):<38} silent (no progress)")
    print()


def run(kernel):
    import shlex

    print()
    print(_c("  FluxCurl 1.0  —  type a URL or 'help' / 'exit'"))
    print(_d("  " + "─" * 48))

    while True:
        try:
            line = input(_y("  curl> ")).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break

        if not line:
            continue
        if line in ("exit", "quit", "q"):
            break
        if line in ("help", "?"):
            _print_usage()
            continue

        # parse args
        try:
            parts = shlex.split(line)
        except ValueError as e:
            print(_r(f"  parse error: {e}")); continue

        if not parts:
            continue

        url         = None
        out_file    = None
        headers_only = False
        raw_mode    = False
        silent      = False

        i = 0
        while i < len(parts):
            p = parts[i]
            if p in ("-o", "--output"):
                i += 1
                if i < len(parts): out_file = parts[i]
            elif p in ("-I", "--head"):
                headers_only = True
            elif p in ("--raw",):
                raw_mode = True
            elif p in ("-s", "--silent"):
                silent = True
            elif not p.startswith("-"):
                url = p
            i += 1

        if not url:
            print(_r("  error: no URL given")); continue

        if not silent:
            print(_d(f"  → {url}"))

        method = "HEAD" if headers_only else "GET"
        status, reason, hdrs, body, elapsed = _do_fetch(
            url, method=method, strip_html=not raw_mode
        )

        if status is None:
            print(_r(f"  error: {body}")); print(); continue

        # status line
        colour = _g if 200 <= status < 300 else _y if 300 <= status < 400 else _r
        print(colour(f"  HTTP {status} {reason}") + _d(f"  ({elapsed*1000:.0f} ms)"))

        if headers_only or not silent:
            print(_d("  " + "─" * 48))

        if headers_only:
            for k, v in sorted(hdrs.items()):
                print(f"  {_c(k)}: {v}")
            print(); continue

        # body
        lines = body.splitlines()
        MAX_LINES = 80
        for ln in lines[:MAX_LINES]:
            print("  " + ln)
        if len(lines) > MAX_LINES:
            print(_d(f"  ... ({len(lines) - MAX_LINES} more lines truncated)"))

        # save to FluxFS
        if out_file:
            if not out_file.startswith("/"):
                out_file = "/home/" + out_file
            ok, msg = kernel.fs.create_file("MainPartition", out_file, content=body)
            if ok:
                print(_g(f"  saved → {out_file}  ({len(body.encode())} bytes)"))
            else:
                print(_r(f"  save failed: {msg}"))

        print()

    print(_d("  curl: bye"))
    print()
